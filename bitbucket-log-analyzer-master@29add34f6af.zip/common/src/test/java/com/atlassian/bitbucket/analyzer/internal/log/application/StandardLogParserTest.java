package com.atlassian.bitbucket.analyzer.internal.log.application;

import org.junit.Test;

import java.util.regex.Matcher;

import static org.junit.Assert.*;

public class StandardLogParserTest {
    //TODO: test regex for standard log
    private static final String LONG_LINE = "2016-12-19 11:03:43,487 ERROR [http-nio-9080-exec-1] " +
            "*1MJAF34x663x507963x2 172.30.210.137,172.24.12.146 " +
            "\"POST /rest/build-status/latest/commits/a8e6b2181f7dbf943f301c926d2c430acc462840 HTTP/1.0\" " +
            "c.a.s.i.build.dao.AoBuildStatusDao Multiple build statuses for commitId " +
            "\"a8e6b2181f7dbf943f301c926d2c430acc462840\" and key \"J73SPT-BPJAH\": " +
            "BuildStatus{name=JIRA 7.3 Stable - Plan templates - BP - JIRA Admin Helper Plugin, state=SUCCESSFUL, " +
            "url=https://server-gdn-bamboo.internal.atlassian.com/browse/J73SPT-BPJAH-86, added=2016-12-16 16:31:29.418}, " +
            "BuildStatus{name=JIRA 7.3 Stable - Plan templates - BP - JIRA Admin Helper Plugin, state=SUCCESSFUL, " +
            "url=https://server-gdn-bamboo.internal.atlassian.com/browse/J73SPT-BPJAH-86, added=2016-12-16 16:31:29.404}";
    private static final String SHORT_LINE = "2014-07-29 00:02:56,444 INFO  [AtlassianEvent::pool-3-thread-2] igerges " +
            "@TZJAA6x2x387105x4 dyw4e0 172.24.36.105 SSH - git-receive-pack '/CONF/confluence.git' " +
            "c.a.bitbucket.bamboo.RefUpdateNotifier ERROR MESSAGE";
    @Test
    public void testLongLine() {
        Matcher matcher = StandardLogParser.LOG_FORMAT.matcher(LONG_LINE);
        assertTrue(matcher.matches());

        assertEquals("2016-12-19 11:03:43,487", matcher.group(1));
        assertEquals("ERROR", matcher.group(2));
        assertEquals("http-nio-9080-exec-1", matcher.group(3));
        assertEquals("c.a.s.i.build.dao.AoBuildStatusDao", matcher.group(5));
        assertTrue(matcher.group(6).startsWith("Multiple build statuses for commitId"));
        assertTrue(matcher.group(6).endsWith(", added=2016-12-16 16:31:29.404}"));
    }

    @Test
    public void testShortLine() {
        Matcher matcher = StandardLogParser.LOG_FORMAT.matcher(SHORT_LINE);
        assertTrue(matcher.matches());

        assertEquals("2014-07-29 00:02:56,444", matcher.group(1));
        assertEquals("INFO", matcher.group(2));
        assertEquals("AtlassianEvent::pool-3-thread-2", matcher.group(3));
        assertEquals("c.a.bitbucket.bamboo.RefUpdateNotifier", matcher.group(5));
        assertEquals("ERROR MESSAGE", matcher.group(6));
    }
}