package com.atlassian.bitbucket.analyzer.internal.log.sample;

public class AbstractSample<S extends AbstractSample<S>> implements Sample<S> {
    private final long timestamp;

    protected AbstractSample(long timestamp) {
        this.timestamp = timestamp;
    }

    @Override
    public long getTimestamp() {
        return timestamp;
    }

    @Override
    public int compareTo(S o) {
        return o.getTimestamp() == this.timestamp ? 0 : (o.getTimestamp() > this.timestamp ? -1 : 1);
    }
}
