package com.atlassian.bitbucket.analyzer.internal.log.callback;

import java.util.Iterator;
import java.util.LinkedList;

public class ConcurrencyMonitor {
    private int startConcurrency;
    private LinkedList<Event> events = new LinkedList<>();

    public void addSample(long startTimestamp, long duration) {
        if (duration < 0) {
            throw new IllegalArgumentException("duration must be >= 0");
        }
        CallbackUtils.insertInWindow(events, new Event(startTimestamp, true));
        CallbackUtils.insertInWindow(events, new Event(startTimestamp + duration, false));
    }

    public ConcurrencyInfo getConcurrency(long startTimestamp, long duration) {
        if (duration < 0) {
            throw new IllegalArgumentException("duration must be >= 0");
        }
        int concurrency = startConcurrency;
        int minConcurrency = startConcurrency;
        int maxConcurrency = startConcurrency;
        long concurrencyMillis = 0;
        long lastEventTimestamp = startTimestamp;
        long endTimestamp = startTimestamp + duration;

        Iterator<Event> it = events.iterator();
        while (it.hasNext() && lastEventTimestamp < endTimestamp) {
            Event event = it.next();
            int newConcurrency = concurrency + (event.start ? 1 : -1);
            if (event.timestamp <= startTimestamp) {
                maxConcurrency = newConcurrency;
                minConcurrency = newConcurrency;
            } else if (event.timestamp < endTimestamp) {
                if (event.start) {
                    maxConcurrency = Integer.max(maxConcurrency, newConcurrency);
                } else {
                    minConcurrency = Integer.min(minConcurrency, newConcurrency);
                }
                concurrencyMillis += (event.timestamp - lastEventTimestamp) * concurrency;
                lastEventTimestamp = event.timestamp;
            } else {
                concurrencyMillis += (endTimestamp - lastEventTimestamp) * concurrency;
                lastEventTimestamp = event.timestamp;
            }
            concurrency = newConcurrency;
        }
        if (lastEventTimestamp < endTimestamp) {
            concurrencyMillis += (endTimestamp - lastEventTimestamp) * concurrency;
        }
        if (concurrencyMillis < (endTimestamp - startTimestamp)) {
            throw new IllegalStateException("incorrect concurrency!");
        }

        return new ConcurrencyInfo(minConcurrency, maxConcurrency, concurrencyMillis / (1.0d * duration));
    }

    public void clear() {
        events.clear();
        startConcurrency = 0;
    }

    public void trim(long timestamp) {
        while (!events.isEmpty()) {
            Event event = events.peek();
            if (event.timestamp > timestamp) {
                return;
            }
            events.pop();
            startConcurrency += event.start ? 1 : -1;
        }
    }

    private static class Event implements Comparable<Event> {
        private final long timestamp;
        private final boolean start;

        private Event(long timestamp, boolean start) {
            this.timestamp = timestamp;
            this.start = start;
        }

        @Override
        public int compareTo(Event o) {
            return (int) (timestamp - o.timestamp);
        }

        public String toString() {
            return "[" + timestamp + ", " + (start ? "start]" : "end]");
        }
    }

    public static class ConcurrencyInfo {
        private final int minimum;
        private final int maximum;
        private final double average;

        public ConcurrencyInfo(int minimum, int maximum, double average) {
            this.minimum = minimum;
            this.maximum = maximum;
            this.average = average;
        }

        public int getMinimum() {
            return minimum;
        }

        public int getMaximum() {
            return maximum;
        }

        public double getAverage() {
            return average;
        }
    }

}
