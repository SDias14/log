package com.atlassian.bitbucket.analyzer.internal.log.access;


import com.atlassian.bitbucket.analyzer.internal.log.Operation;
import com.atlassian.bitbucket.analyzer.internal.log.sample.RequestSample;

import java.util.*;

import static com.atlassian.bitbucket.analyzer.internal.log.Operation.*;

public class AccessLogSample implements RequestSample<AccessLogSample> {

    private static final String SEP = " ; ";

    private final List<Operation> operations;
    private final String remoteAddress;
    private final String protocol;
    private final String requestId;
    private final String repository;
    private final long requestNumber;
    private final String username;
    private final Date startDate;
    private final Date endDate;
    private final String action;
    private final String details;
    private final Integer statusCode;
    private final Long bytesRead;
    private final Long bytesWritten;
    private final Set<String> labels;
    private final Integer duration;
    private final String sessionId;
    private final String nodeId;
    private final boolean out;
    private final int overallConcurrency;
    private long concurrency;

    public AccessLogSample(String remoteAddress, String protocol, String requestId, String username, Date date,
                           String action, String repository, String details, Integer statusCode, Long bytesRead,
                           Long bytesWritten, String[] labels, Integer duration, String sessionId) {
        this.remoteAddress = remoteAddress;
        this.protocol = protocol;
        this.requestId = requestId;
        this.username = username;
        this.action = action;
        this.repository = repository;
        this.details = details;
        this.statusCode = statusCode;
        this.bytesRead = bytesRead;
        this.bytesWritten = bytesWritten;
        this.labels = new HashSet<>();
        for (String label : labels) {
            this.labels.add(label.trim());
        }
        this.duration = duration;
        this.sessionId = sessionId;

        // requestId format: o1230x8213315x4 or o@1opm1u9x325x199851x2
        int concurrencyStart = requestId.lastIndexOf('x');
        int requestNumberStart = requestId.lastIndexOf('x', concurrencyStart - 1);

        try {
            this.requestNumber = Integer.parseInt(requestId.substring(requestNumberStart + 1, concurrencyStart));
            this.overallConcurrency = Integer.parseInt(requestId.substring(concurrencyStart + 1));
        } catch (NumberFormatException e) {
            throw new NumberFormatException("requestId: " + requestId + " - " + e.getMessage());
        }

        if (requestId.charAt(1) == '@' || requestId.charAt(1) == '*') {
            // node ID included in request ID
            nodeId = requestId.substring(2, requestId.indexOf('x', 1));
        } else {
            nodeId = "";
        }

        this.out = requestId.charAt(0) == 'o';

        if (this.out) {
            this.startDate = new Date(date.getTime() - duration);
            this.endDate = date;
        } else {
            this.startDate = date;
            this.endDate = null;
        }

        this.operations = parseOperations(protocol, action, this.labels);
    }

    public AccessLogSample(String remoteAddress, String protocol, String requestId, String username, Date date,
                           String action, String repository, String details, String[] labels, Integer duration, String
                                   sessionId) {
        this(remoteAddress, protocol, requestId, username, date, action, repository,details, null,null,null,labels,duration, sessionId);
    }

    @Override
    public int compareTo(AccessLogSample o) {
        int result = startDate.compareTo(o.getStartDate());
        if (result == 0) {
            result = requestId.compareTo(o.getRequestId());
        }
        return result;
    }

    public String getAction() {
        return action;
    }

    public long getConcurrency() {
        return concurrency;
    }

    public void setConcurrency(long concurrency) {
        this.concurrency = concurrency;
    }

    public String getDetails() {
        return details;
    }

    public Integer getStatusCode() {
        return statusCode;
    }

    public Long getBytesRead() {
        return bytesRead;
    }

    public Long getBytesWritten() {
        return bytesWritten;
    }

    public Integer getDuration() {
        return duration;
    }

    public Set<String> getLabels() {
        return labels;
    }

    public String getNodeId() {
        return nodeId;
    }

    public Operation getOperation() {
        ListIterator<Operation> it = operations.listIterator(operations.size());
        while (it.hasPrevious()) {
            Operation op = it.previous();
            if (!op.isCategory()) {
                return op;
            }
        }

        return operations.isEmpty() ? null : operations.get(operations.size() - 1);
    }

    public Collection<Operation> getOperations() {
        return operations;
    }

    public int getOverallConcurrency() {
        return overallConcurrency;
    }

    public String getProtocol() {
        return protocol;
    }

    public String getRemoteAddress() {
        return remoteAddress;
    }

    public String getRepository() {
        return repository;
    }

    public String getRequestId() {
        return requestId;
    }

    public long getRequestNumber() {
        return requestNumber;
    }

    public String getSessionId() {
        return sessionId;
    }

    public Date getStartDate() {
        return startDate;
    }

    public long getTimestamp() {
        return startDate == null ? -1L : startDate.getTime();
    }

    public String getUsername() {
        return username;
    }

    public boolean isCacheHit() {
        return labels.contains("cache:hit");
    }

    public boolean isCacheMiss() {
        return labels.contains("cache:miss");
    }

    public boolean isOut() {
        return out;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("[");
        String sep = "";
        for (Operation op : operations) {
            builder.append(sep).append(op);
            sep = ", ";
        }
        return builder
                .append("]").append(SEP)
                .append(protocol).append(SEP)
                .append(action).append(SEP)
                .append(startDate.getTime()).append(SEP)
                .append(endDate != null ? endDate.getTime() : "").append(SEP)
                .append(blankNull(duration)).append(SEP)
                .append(blankNull(username)).append(SEP)
                .append(requestId).append(SEP)
                .append(blankNull(sessionId)).append(SEP)
                .append(isCacheHit()).append(SEP)
                .append(concurrency).append(SEP)
                .append(overallConcurrency)
                .toString();
    }

    private static List<Operation> parseOperations(String protocol, String action, Set<String> labels) {
        List<Operation> ops = new ArrayList<>();
        ops.add(ALL);

        if(protocol.equals("ssh")){
            // All SSH activity
            ops.add(SSH);
            if (action.contains("git-")) {
                ops.add(HOSTING);
                ops.add(SSH_HOSTING);

                if (labels.contains("protocol:1")) {
                    ops.add(HOSTING_PROTOCOL_1);
                    ops.add(SSH_HOSTING_PROTOCOL_1);
                } else if (labels.contains("protocol:2")) {
                    ops.add(HOSTING_PROTOCOL_2);
                    ops.add(SSH_HOSTING_PROTOCOL_2);
                }
                if (labels.contains("refs") && !labels.contains("fetch") && !labels.contains("clone")) {
                    ops.add(HOSTING_REFS);
                    ops.add(SSH_HOSTING_REFS);
                } else if (action.contains("git-upload-pack") || labels.contains("clone")) {
                    if (labels.contains("shallow negotiation") || labels.contains("negotiation")) {
                        ops.add(HOSTING_NEGOTIATION);
                        ops.add(SSH_HOSTING_NEGOTIATION);
                    } else if (labels.contains("clone") || labels.contains("shallow clone")) {
                        ops.add(HOSTING_CLONE);
                        ops.add(SSH_HOSTING_CLONE);
                    } else if (labels.contains("fetch") || labels.contains("shallow fetch")) {
                        ops.add(HOSTING_FETCH);
                        ops.add(SSH_HOSTING_FETCH);
                    } else {
                        ops.add(HOSTING_UPLOAD_PACK_UNCLASSIFIED);
                        ops.add(SSH_HOSTING_UPLOAD_PACK_UNCLASSIFIED);
                    }
                } else if (action.contains("git-receive-pack")) {
                    ops.add(HOSTING_PUSH);
                    ops.add(SSH_HOSTING_PUSH);
                } else if (action.contains("git-upload-archive")) {
                    ops.add(SSH_HOSTING_ARCHIVE);
                }
            } else {
                ops.add(SSH_CUSTOM);
            }
        } else {
            // All HTTP activity
            ops.add(HTTP);

            if (action.contains(" /scm/") || action.contains(" /git/")) {
                ops.add(HOSTING);
                ops.add(HTTP_HOSTING);

                if (labels.contains("protocol:1")) {
                    ops.add(HOSTING_PROTOCOL_1);
                    ops.add(HTTP_HOSTING_PROTOCOL_1);
                } else if (labels.contains("protocol:2")) {
                    ops.add(HOSTING_PROTOCOL_2);
                    ops.add(HTTP_HOSTING_PROTOCOL_2);
                }

                if ((action.contains("/info/refs ") && !labels.contains("protocol:2")) || labels.contains("refs")) {
                    ops.add(HOSTING_REFS);
                    ops.add(HTTP_HOSTING_REFS);
                } else if (action.contains("git-upload-pack")) {
                    if (labels.contains("shallow negotiation") || labels.contains("negotiation")) {
                        ops.add(HOSTING_NEGOTIATION);
                        ops.add(HTTP_HOSTING_NEGOTIATION);
                    } else if (labels.contains("clone") || labels.contains("shallow clone")) {
                        ops.add(HOSTING_CLONE);
                        ops.add(HTTP_HOSTING_CLONE);
                    } else if (labels.contains("fetch") || labels.contains("shallow fetch")) {
                        ops.add(HOSTING_FETCH);
                        ops.add(HTTP_HOSTING_FETCH);
                    } else {
                        ops.add(HOSTING_UPLOAD_PACK_UNCLASSIFIED);
                        ops.add(HTTP_HOSTING_UPLOAD_PACK_UNCLASSIFIED);
                    }
                } else if (action.contains("git-receive-pack")) {
                    ops.add(HTTP_HOSTING_PUSH);
                }
            } else if (action.contains(("DELETE "))) {
                // process DELETEs separately because they get called both with and without the /rest/api/ prefix
                // because of internal URL rewriting
                ops.add(REST_DELETE);
                ops.add(REST);
                if (action.contains(("/projects/")) && action.contains(("/repos/"))) {
                    ops.add(action.contains("/repos/") ? REST_DELETE_REPOSITORY : REST_DELETE_PROJECT);
                } else {
                    ops.add(REST_UNCLASSIFIED);
                }
            } else if (action.contains(" /rest/")) {
                ops.add(REST);
                if (action.contains("/rest/api/")) {
                    ops.add(REST_API);
                    if (action.contains("/inbox/pull-requests")) {
                        ops.add(REST_INBOX);
                    } else if (action.contains("/pull-requests/")) {
                        ops.add(REST_PULL_REQUEST);
                        if (action.contains("/merge")) {
                            ops.add(REST_PR_MERGE);
                        } else if (action.contains("/activities")) {
                            ops.add(REST_PR_ACTIVITIES);
                        }
                    } else if (action.contains("/profile/recent/repos")) {
                        ops.add(REST_RECENT_REPOS);
                    } else if (action.contains("/dashboard/pull-requests ")) {
                        ops.add(REST_DASHBOARD_PRS);
                    } else if (action.contains("/dashboard/pull-request-suggestions ")) {
                        ops.add(REST_DASHBOARD_PR_SUGGESTIONS);
                    } else if (action.contains("/pull-requests ")) {
                        ops.add(REST_PR_LIST);
                    }
                } else if (action.contains("/rest/analytics/")) {
                    ops.add(REST_ANALYTICS);
                } else if (action.contains("/rest/build-status/")) {
                    ops.add(REST_BUILD_STATUS);
                } else if (action.contains("/rest/activity-stream/")) {
                    ops.add(REST_ACTIVITY_STREAM);
                } else if (action.contains("/rest/capabilities/")) {
                    ops.add(REST_CAPABILITIES);
                } else if (action.contains("/rest/chaperone/")) {
                    ops.add(REST_CHAPERONE);
                } else if (action.contains("/rest/insights/")) {
                    ops.add(REST_INSIGHTS);
                } else if (action.contains("/rest/menu/")) {
                    ops.add(REST_MENU);
                } else if (action.contains("/rest/mirroring/")) {
                    ops.add(REST_MIRRORING);
                } else if (action.contains("/rest/remote-event/")) {
                    ops.add(REST_REMOTE_EVENT);
                } else if (action.contains("/rest/shortcuts/")) {
                    ops.add(REST_SHORTCUTS);
                } else if (action.contains("/rest/jira/")) {
                    ops.add(REST_JIRA);
                } else {
                    ops.add(REST_UNCLASSIFIED);
                }
            } else if (action.contains(" /plugins/")) {
                ops.add(PLUGIN);

                if (action.contains("/plugins/servlet/mirror/")) {
                    ops.add(PLUGIN_MIRROR_PULL);
                }
            } else if (action.contains((" /status"))) {
                ops.add(STATUS);
            } else if (action.contains((" /mvc/maintenance"))) {
                ops.add(MAINTENANCE);
            } else {
                ops.add(UI);

                if (action.contains(" /s/")) {
                    ops.add(UI_STATIC_RESOURCES);
                } else if (action.contains("/j_spring_security_check")) {
                    ops.add(UI_LOGIN);
                } else if (action.contains("/projects ")) {
                    ops.add(UI_PROJECT_LIST);
                } else if (action.contains("/repos ")) {
                    ops.add(UI_REPO_LIST);
                } else if (action.contains("/repos/") && action.contains("/browse")) {
                    ops.add(UI_REPO_BROWSE);
                } else if (action.contains("/pull-requests ")) {
                    ops.add(UI_PULL_REQUEST_LIST);
                } else if (action.contains("/pull-requests/")) {
                    if (action.contains("/diff ")) {
                        ops.add(UI_PULL_REQUEST_DIFF);
                    } else if (action.contains("/activity")) {
                        ops.add(UI_PULL_REQUEST_ACTIVITY);
                    } else if (action.contains("/overview")) {
                        ops.add(UI_PULL_REQUEST_OVERVIEW);
                    } else if (action.contains("/commits")) {
                        ops.add(UI_PULL_REQUEST_COMMITS);
                    }
                } else {
                    ops.add(UI_UNCLASSIFIED);
                }
            }
        }
        return ops;
    }

    private Object blankNull(Object value) {
        return value == null ? "" : value;
    }
}
