package com.atlassian.bitbucket.analyzer.internal.log.access;

import com.atlassian.bitbucket.analyzer.internal.log.AbstractLogParser;
import com.atlassian.bitbucket.analyzer.internal.log.ParserConfiguration;

import java.nio.file.Path;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class AccessLogParser extends AbstractLogParser<AccessLogSample> {
    private static final String[] NO_LABELS = new String[0];

    private SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss,SSS");

    public AccessLogParser(ParserConfiguration configuration) {
        super(configuration);
    }

    private static String trimGit(String value) {
        return value.endsWith(".git") ? value.substring(0, value.length() - 4) : value;
    }

    private static Integer tryParse(String obj, Integer defaultValue) {
        if (obj == null) {
            return defaultValue;
        }
        Integer retVal;
        try {
            retVal = Integer.valueOf(obj);
        } catch (NumberFormatException nfe) {
            retVal = defaultValue;
        }
        return retVal;
    }

    @Override
    protected boolean includeFile(Path path) {
        return path.getFileName().toString().matches("atlassian-(bitbucket|stash)-access.*\\.log");
    }

    @Override
    protected AccessLogSample toSample(String line) {
        String[] parts = line.split(" \\| ");
        if (parts.length == 13) {
            return toBitbucketSample(parts);
        } else if (parts.length == 10) {
            return toStashSample(parts);
        }
        System.err.println("Found a bad line: " + line + ", ignoring");
        //throw new IllegalStateException("Found a bad line: " + line + ", aborting");
        return null;
    }

    private AccessLogSample toStashSample(String[] parts) {

        //line format -- REMOTE_ADRESS | PROTOCOL | (o|i)REQUEST_ID | USERNAME | date |  URL | DETAILS | LABELS | TIME | SESSION_ID |
        //example: 59.167.133.100,172.16.1.187 | https | o1230x8213315x4 | mchai | 2012-10-24 20:30:34,633 | "GET /projects/CONF/repos/confluence/browse HTTP/1.1" | "https://confluence-bamboo.atlassian.com/browse/CONFSTAB-MAIN4-10" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.7; rv:16.0) Gecko/20100101 Firefox/16.0" | - | 1597 | 13izoq1 |

        String remoteAddress = parts[0];
        String protocol = parts[1];
        String requestId = parts[2];

        String username = nullIfDash(parts[3]);
        String dateString = parts[4];
        String url = parts[5];
        String details = nullIfDash(parts[6]);
        String labelString = parts[7];
        String durationStr = nullIfDash(parts[8]);
        String sessionId = nullIfDash(parts[9]);

        String repository = parseRepositoryFromAction(url);

        //convert types
        Date date;
        try {
            date = simpleDateFormat.parse(dateString);
        } catch (ParseException e) {
            System.err.println("Found a bad date: " + dateString + ", skipping");
            return null;
        }
        Integer duration = "-".equals(durationStr) ? null : tryParse(durationStr, null);
        String[] labels = parseLabels(labelString);
        return new AccessLogSample(remoteAddress, protocol, requestId,
                username, date, url, repository, details, labels, duration, sessionId);
    }

    private AccessLogSample toBitbucketSample(String[] parts) {
        //line format -- REMOTE_ADRESS | PROTOCOL | (o|i)REQUEST_ID | USERNAME | date |  URL | DETAILS | STATUS_CODE | BYTES_READ | BYTES_WRITTEN | LABELS | TIME | SESSION_ID |
        //example: 59.167.133.100,172.16.1.187 | https | o1230x8213315x4 | mchai | 2012-10-24 20:30:34,633 | "GET /projects/CONF/repos/confluence/browse HTTP/1.1" | "https://confluence-bamboo.atlassian.com/browse/CONFSTAB-MAIN4-10" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.7; rv:16.0) Gecko/20100101 Firefox/16.0" | 200 | 321 | 123 | - | 1597 | 13izoq1 |

        String remoteAddress = parts[0];
        String protocol = parts[1];
        String requestId = parts[2];

        String username = nullIfDash(parts[3]);
        String dateString = parts[4];
        String url = parts[5];
        String details = nullIfDash(parts[6]);
        Integer statusCode = parseInteger(parts[7]);
        Long bytesRead = parseLong(parts[8]);
        Long bytesWritten = parseLong(parts[9]);
        String labelString = parts[10];
        String durationStr = nullIfDash(parts[11]);
        String sessionId = nullIfDash(parts[12]);

        String repository = parseRepositoryFromAction(url);

        //convert types
        Date date;
        try {
            date = simpleDateFormat.parse(dateString);
        } catch (ParseException e) {
            throw new IllegalStateException("Found a bad date: " + dateString + ", aborting", e);
        }
        Integer duration = "-".equals(durationStr) ? null : tryParse(durationStr, null);
        String[] labels = parseLabels(labelString);
        return new AccessLogSample(remoteAddress, protocol, requestId,
                username, date, url, repository, details, statusCode, bytesRead, bytesWritten, labels,
                duration, sessionId);
    }

    private Long parseLong(String intStr) {
        if ("-".equals(intStr)) {
            return null;
        }
        Long retVal;
        try {
            retVal = Long.valueOf(intStr);
        } catch (NumberFormatException nfe) {
            retVal = null;
        }
        return retVal;
    }

    private Integer parseInteger(String longStr) {
        if ("-".equals(longStr)) {
            return null;
        }
        Integer retVal;
        try {
            retVal = Integer.valueOf(longStr);
        } catch (NumberFormatException nfe) {
            retVal = null;
        }
        return retVal;
    }

    private String[] parseLabels(String labelString) {
        if (labelString == null || labelString.isEmpty() || labelString.equals("-")) {
            return NO_LABELS;
        }

        return labelString.split(", ");
    }

    private String parseRepositoryFromAction(String action) {
        if (action == null) {
            return null;
        }

        if (action.contains("SSH")) {
            // look for 'PKEY/repos_slug'
            int index = action.indexOf('\'');
            if (index == -1) {
                return null;
            }
            index++;
            if (action.charAt(index) == '/') {
                index++;
            }
            int endIndex = action.indexOf('\'', index);
            if (endIndex == -1) {
                return null;
            }
            return trimGit(action.substring(index, endIndex).toLowerCase());
        }

        // try HTTP hosting URL
        int index = action.indexOf(" /scm/");
        if (index == -1) {
            index = action.indexOf((" /git/"));
        }
        if (index != -1) {
            // HTTP hosting URL
            index += 6;
            int endIndex = action.indexOf('/', index);
            if (endIndex == -1) {
                // invalid hosting URL
                return null;
            }
            endIndex = action.indexOf('/', endIndex + 1);
            if (endIndex == -1) {
                // invalid hosting URL
                return null;
            }
            return trimGit(action.substring(index, endIndex).toLowerCase());
        }

        // try /projects/pkey/repos/slug
        index = action.indexOf("/repos/");
        if (index == -1) {
            return null;
        }
        int projectIndex = action.lastIndexOf('/', index - 1);
        if (projectIndex == -1) {
            return null;
        }
        String project = action.substring(projectIndex + 1, index).toLowerCase();
        index += 6;
        int endIndex = action.indexOf('/', index + 1);
        if (endIndex != -1) {
            return project + action.substring(index, endIndex).toLowerCase();
        }
        return null;
    }
}
