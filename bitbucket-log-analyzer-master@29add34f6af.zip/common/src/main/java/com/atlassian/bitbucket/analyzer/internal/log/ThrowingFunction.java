package com.atlassian.bitbucket.analyzer.internal.log;


@FunctionalInterface
public interface ThrowingFunction<T, R, E extends Exception> {
    /**
     * Applies this function to the given argument.
     *
     * @param t the function argument
     * @return the function result
     * @throws E
     */
    R apply(T t) throws E;
}
