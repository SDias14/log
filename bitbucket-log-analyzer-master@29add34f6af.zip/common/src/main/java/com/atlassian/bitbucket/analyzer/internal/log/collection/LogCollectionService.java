package com.atlassian.bitbucket.analyzer.internal.log.collection;

import javax.annotation.Nonnull;
import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

public interface LogCollectionService {

    @Nonnull
    LogCollection create(@Nonnull String name);

    @Nonnull
    Optional<LogCollection> get(@Nonnull String name);

    @Nonnull
    Stream<LogCollection> stream();

    @Nonnull
    List<ImportDetails> getImports(@Nonnull LogCollection logCollection) throws IOException;
}
