package com.atlassian.bitbucket.analyzer.internal.log.collection;

import com.atlassian.bitbucket.analyzer.internal.log.sample.Sample;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Path;
import java.util.Date;
import java.util.Properties;

/**
 * A summary of the data that has been imported
 */
public class ImportDetails {
    private static String KEY_DATE = "date";
    private static String KEY_FIRST_DATE = "sample.first";
    private static String KEY_LAST_DATE = "sample.last";
    private static String KEY_COUNT = "sample.count";

    private final Date firstSampleDate;
    private final Date importDate;
    private final Date lastSampleDate;
    private final long numberOfSamples;

    private ImportDetails(Builder builder) {
        this.firstSampleDate = builder.firstSampleDate;
        this.importDate = builder.importDate;
        this.lastSampleDate = builder.lastSampleDate;
        this.numberOfSamples = builder.numberOfSamples;
    }

    private ImportDetails(Properties properties) {
        this.firstSampleDate = new Date(Long.parseLong(properties.getProperty(KEY_FIRST_DATE)));
        this.importDate = new Date(Long.parseLong(properties.getProperty(KEY_DATE)));
        this.lastSampleDate = new Date(Long.parseLong(properties.getProperty(KEY_LAST_DATE)));
        this.numberOfSamples = Long.parseLong(properties.getProperty(KEY_COUNT));
    }

    public static ImportDetails load(Path path) throws IOException {
        Properties properties = new Properties();
        try (InputStream is = new FileInputStream(path.toFile())) {
            properties.load(is);
            return new ImportDetails(properties);
        }
    }

    public Date getFirstSampleDate() {
        return firstSampleDate;
    }

    public Date getImportDate() {
        return importDate;
    }

    public Date getLastSampleDate() {
        return lastSampleDate;
    }

    public long getNumberOfSamples() {
        return numberOfSamples;
    }

    public void save(Path path) throws IOException {
        Properties properties = new Properties();
        if (importDate != null) {
            properties.setProperty(KEY_DATE, Long.toString(importDate.getTime()));
        }
        if (firstSampleDate != null) {
            properties.setProperty(KEY_FIRST_DATE, Long.toString(firstSampleDate.getTime()));
        }
        if (lastSampleDate != null) {
            properties.setProperty(KEY_LAST_DATE, Long.toString(lastSampleDate.getTime()));
        }
        properties.setProperty(KEY_COUNT, Long.toString(numberOfSamples));
        try (OutputStream os = new FileOutputStream(path.toFile())) {
            properties.store(os, "Imported on " + importDate);
        }
    }

    public static class Builder {
        private Date firstSampleDate;
        public Date importDate;
        private Date lastSampleDate;
        private long numberOfSamples;

        public Builder() {
            importDate = new Date();
        }

        public Builder addSample(Sample sample) {
            ++numberOfSamples;
            lastSampleDate = new Date(sample.getTimestamp());
            if (firstSampleDate == null) {
                firstSampleDate = lastSampleDate;
            }
            return this;
        }

        public Builder importDate(Date value) {
            importDate = value;
            return this;
        }

        public ImportDetails build() {
            return new ImportDetails(this);
        }
    }
}
