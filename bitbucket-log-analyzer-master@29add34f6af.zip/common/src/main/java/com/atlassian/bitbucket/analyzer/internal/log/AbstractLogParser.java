package com.atlassian.bitbucket.analyzer.internal.log;

import com.atlassian.bitbucket.analyzer.internal.log.callback.SampleCallback;
import com.atlassian.bitbucket.analyzer.internal.log.sample.AutoCloseableIterator;
import com.atlassian.bitbucket.analyzer.internal.log.util.MergingAutoCloseableIterator;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static java.nio.charset.StandardCharsets.UTF_8;

/**
 */
public abstract class AbstractLogParser<S extends Comparable<S>> {

    private static final long DAY_MINUS_1_S = (TimeUnit.DAYS.toMillis(1) - 1000);
    private static final Pattern LOG_FILE_PATTERN = Pattern.compile("(.+?)(?:-([0-9]{4})-([0-9]{2})-([0-9]{2}))?(?:.([0-9]+))?.log");
    private static final Comparator<Path> LOG_FILE_COMPARATOR = (o1, o2) -> {
        String name1 = o1.getFileName().toString();
        String name2 = o2.getFileName().toString();

        Matcher matcher1 = LOG_FILE_PATTERN.matcher(name1);
        Matcher matcher2 = LOG_FILE_PATTERN.matcher(name2);
        if (matcher1.matches() && matcher2.matches()) {
            // group 1=logfile name, 2=year, 3=month, 4=day, 5=day-index
            int result = matcher1.group(1).compareTo(matcher2.group(1));
            if (result != 0) {
                return result;
            }

            if (matcher1.group(2) == null) {
                // no date provided in the log file - o1 is always latest
                return 1;
            }
            if (matcher2.group(2) == null) {
                // no date provided in the log file - o2 is always latest
                return -1;
            }
            for (int group = 2; group < 5; ++group) { // year, month, dday
                // same file names, both have dates
                // years
                result = Integer.valueOf(matcher1.group(group)).compareTo(Integer.valueOf(matcher2.group(group)));
                if (result != 0) {
                    return result;
                }
            }
            if (matcher1.group(5) != null && matcher2.group(5) != null) {
                return Integer.valueOf(matcher1.group(5)).compareTo(Integer.valueOf(matcher2.group(5)));
            }
        }

        return name1.compareTo(name2);
    };

    protected final ParserConfiguration configuration;
    private long sampleCount = 0L;

    protected AbstractLogParser(ParserConfiguration configuration) {
        this.configuration = configuration;
    }

    private static Date getDateFromFilename(Path path) {
        Matcher matcher = LOG_FILE_PATTERN.matcher(path.getFileName().toString());
        if (!matcher.matches()) {
            return null;
        }
        // group 1=logfile name, 2=year, 3=month, 4=day, 5=day-index
        String year = matcher.group(2);
        String month = matcher.group(3);
        String day = matcher.group(4);
        if (year == null || month == null || day == null) {
            return null;
        }
        GregorianCalendar calendar = new GregorianCalendar();
        calendar.set(Calendar.YEAR, Integer.parseInt(year));
        calendar.set(Calendar.MONTH, Integer.parseInt(month) - 1);
        calendar.set(Calendar.DAY_OF_MONTH, Integer.parseInt(day));
        calendar.set(Calendar.HOUR, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);

        return calendar.getTime();
    }

    @SafeVarargs
    public final void parse(SampleCallback<S>... callbacks) throws IOException {
        long start = System.currentTimeMillis();
        onStart(callbacks);

        try (AutoCloseableIterator<S> it = getSamples()) {
            while (it.hasNext()) {
                onSample(it.next(), callbacks);
                ++sampleCount;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            onFinish(callbacks);
            double timeSec = (System.currentTimeMillis() - start) / 1000.0;
            double speed = sampleCount / timeSec;

            System.out.println("Processed " + sampleCount / 2 + " in " + timeSec + "s (" + speed + " samples/s)");
        }
    }

    private AutoCloseableIterator<S> getSamples() throws IOException {
        List<Path> nodes = getNodeDirectories();
        if (nodes.isEmpty()) {
            return getSamples(configuration.getLogFileDirectory());
        }

        List<AutoCloseableIterator<S>> nodeSamples = nodes.stream()
                .map(this::getSamples)
                .collect(Collectors.toList());
        return new MergingAutoCloseableIterator<>(nodeSamples, Comparable::compareTo);
    }

    private AutoCloseableIterator<S> getSamples(Path logDirPath) {
        return new SampleIterator(getLogFiles(logDirPath).iterator());
    }

    private List<Path> getNodeDirectories() throws IOException {
        return Files.list(configuration.getLogFileDirectory())
                .filter(p -> p.getFileName().toString().startsWith("node"))
                .filter(p -> p.toFile().isDirectory())
                .collect(Collectors.toList());
    }

    protected abstract boolean includeFile(Path path);

    protected String nullIfDash(String value) {
        return "-".equals(value) ? null : value;
    }

    protected S onEof() {
        return null;
    }

    protected abstract S toSample(String line);

    private List<Path> getLogFiles(Path directoryPath) {
        File directory = directoryPath.toFile();
        if (!directory.exists() || directory.isFile()) {
            throw new IllegalArgumentException("directory does not exist");
        }

        try {
            return Files.list(directoryPath)
                    .filter(Files::isRegularFile)
                    .filter(this::includeFile)
                    .filter(this::withinDateRange)
                    .sorted(LOG_FILE_COMPARATOR)
                    .collect(Collectors.toList());
        } catch (IOException e) {
            return Collections.emptyList();
        }
    }

    @SafeVarargs
    private final void onSample(S sample, SampleCallback<S>... callbacks) {
        if (sample != null) {
            for (SampleCallback<S> callback : callbacks) {
                try {
                    callback.onSample(sample);
                } catch (Exception e) {
                    System.out.println("Error in onSample: " + e.getMessage());
                    e.printStackTrace();
                }
            }
        }
    }

    @SafeVarargs
    private final void onStart(SampleCallback<S>... callbacks) throws IOException {
        for (SampleCallback<S> callback : callbacks) {
            callback.start();
        }
    }

    @SafeVarargs
    private final void onFinish(SampleCallback<S>... callbacks) throws IOException {
        for (SampleCallback<S> callback : callbacks) {
            callback.finish();
        }
    }

    private boolean withinDateRange(Path path) {
        Date from = configuration.getFromDate();
        Date to = configuration.getToDate();
        if (from == null && to == null) {
            return true;
        }
        Date fileDate = getDateFromFilename(path);
        if (fileDate == null) {
            return true;
        }

        // from:2015/1/1 12:12 - 2015/1/3 6:00 => all 1/1, 1/2 and 1/3 files should be included
        if (from != null && fileDate.getTime() < from.getTime() - DAY_MINUS_1_S) {
            return false;
        }
        if (to != null && fileDate.getTime() > to.getTime() + DAY_MINUS_1_S) {
            return false;
        }
        return true;
    }

    private class SampleIterator implements AutoCloseableIterator<S> {
        private final Iterator<Path> paths;
        private BufferedReader reader;

        private S nextSample;

        private SampleIterator(Iterator<Path> paths) {
            this.paths = paths;
        }

        @Override
        public void close() {
            closeReader();
        }

        @Override
        public boolean hasNext() {
            String line = null;
            while (nextSample == null && (line = readLine()) != null) {
                nextSample = toSample(line);
            }
            if (nextSample == null) {
                // depleted the stream,
                nextSample = onEof();
            }
            return nextSample != null;
        }

        @Override
        public S next() {
            if (hasNext()) {
                S result = nextSample;
                nextSample = null;
                return result;
            }
            throw new NoSuchElementException("iterator is depleted");
        }

        private void closeReader() {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                reader = null;
            }
        }
        private String readLine() {
            String line;
            while (reader != null || paths.hasNext()) {
                try {
                    if (reader == null) {
                        reader = Files.newBufferedReader(paths.next(), UTF_8);
                    }
                    line = reader.readLine();
                    if (line == null) {
                        // eof in current file
                        closeReader();
                    } else {
                        // line found
                        return line;
                    }
                } catch (IOException e) {
                    // error, done with this path. Move on to the next
                    e.printStackTrace();
                    closeReader();
                }
            }
            return null;
        }

    }
}
