package com.atlassian.bitbucket.analyzer.internal.log.callback;

import java.util.List;
import java.util.ListIterator;

public class CallbackUtils {
    public static <T extends Comparable<T>> void insertInWindow(List<T> list, T sample) {
        ListIterator<T> it = list.listIterator(list.size());
        while (it.hasPrevious()) {
            T existing = it.previous();
            if (sample.compareTo(existing) >= 0) {
                if (it.hasNext()) {
                    // insert after 'existing'
                    it.next();
                    it.add(sample);
                } else {
                    list.add(sample);
                }
                return;
            }
        }

        // sample was smaller than anything in the list, prepend it
        list.add(0, sample);
    }
}
