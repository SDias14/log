package com.atlassian.bitbucket.analyzer.internal.log.collection;

import com.atlassian.bitbucket.analyzer.internal.log.DataFileHeaderV1;
import com.atlassian.bitbucket.analyzer.internal.log.Operation;
import com.atlassian.bitbucket.analyzer.internal.log.ThrowingFunction;
import com.atlassian.bitbucket.analyzer.internal.log.access.CacheRatioSample;
import com.atlassian.bitbucket.analyzer.internal.log.access.ConcurrencySample;
import com.atlassian.bitbucket.analyzer.internal.log.access.RequestStatisticsSample;
import com.atlassian.bitbucket.analyzer.internal.log.application.Problem;
import com.atlassian.bitbucket.analyzer.internal.log.callback.SampleCallback;
import com.atlassian.bitbucket.analyzer.internal.log.sample.Sample;
import com.atlassian.bitbucket.analyzer.internal.log.store.DataStore;
import com.atlassian.bitbucket.analyzer.internal.log.store.DataType;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Stream;

public class DefaultDataService implements DataService {

    public DefaultDataService() {
    }

    @Override
    public void streamCacheRatio(DataStore store, Date fromDate, Date toDate, int intervalMinute,
                                 Operation operation, Consumer<CacheRatioSample> callback) throws IOException {

        SampleInterpolatingCallback<CacheRatioSample> interpolatingCallback =
                new SampleInterpolatingCallback<>(callback, this::combineCacheRatio,
                        TimeUnit.MINUTES.toSeconds(intervalMinute));

        streamSamples(store, fromDate, toDate, operation, DataType.CACHE_RATIO, CacheRatioSample::readFrom,
                interpolatingCallback);
    }

    @Override
    public void streamConcurrency(DataStore dataStore, Date dateFrom, Date dateTo, int intervalMinute,
                                  Operation operation, Consumer<ConcurrencySample> callback) throws IOException {

        SampleInterpolatingCallback<ConcurrencySample> interpolatingCallback =
                new SampleInterpolatingCallback<>(callback, this::combineConcurrency,
                        TimeUnit.MINUTES.toSeconds(intervalMinute));

        streamSamples(dataStore, dateFrom, dateTo, operation, DataType.CONCURRENCY, ConcurrencySample::readFrom,
                interpolatingCallback);
    }

    @Override
    public void streamProblems(DataStore dataStore, Date dateFrom, Date dateTo, Function<Problem, String> hashFunction,
                               Consumer<Problem> callback) throws IOException {
        streamSamples(dataStore, dateFrom, dateTo, null, DataType.PROBLEMS, Problem::readFrom,
                new ProblemMergingCallback(callback, hashFunction));
    }

    @Override
    public void streamRequestStatistics(DataStore store, Date fromDate, Date toDate, int intervalMinute,
                                        Operation operation, Consumer<RequestStatisticsSample> callback) throws IOException {

        SampleInterpolatingCallback<RequestStatisticsSample> interpolatingCallback =
                new SampleInterpolatingCallback<>(callback, this::combineRequestStatistics,
                        TimeUnit.MINUTES.toSeconds(intervalMinute));

        streamSamples(store, fromDate, toDate, operation, DataType.REQUEST_STATISTICS, RequestStatisticsSample::readFrom,
                interpolatingCallback);
    }

    private CacheRatioSample combineCacheRatio(Long startTimestamp, double samplesInInterval,
                                               List<CacheRatioSample> samples) {
        int hits = 0, misses = 0, other = 0;
        for (CacheRatioSample sample : samples) {
            hits += sample.getHits();
            misses += sample.getMisses();
            other += sample.getOther();
        }
        return new CacheRatioSample(startTimestamp, hits, misses, other);
    }

    private ConcurrencySample combineConcurrency(Long startTimestamp, int samplesInInterval,
                                                 List<ConcurrencySample> samples) {
        if (samples.isEmpty()) {
            return new ConcurrencySample(startTimestamp, 0, 0, 0);
        }

        int max = 0;
        int min = Integer.MAX_VALUE;
        double sumAverages = 0;
        for (ConcurrencySample sample : samples) {
            max = Math.max(max, sample.getMax());
            min = Math.min(min, sample.getMin());
            sumAverages += sample.getAvg();
        }
        if (samples.size() < samplesInInterval) {
            // there was a time in the interval where there were 0 active requests
            min = 0;
        }
        return new ConcurrencySample(startTimestamp, min, sumAverages / samplesInInterval, max);
    }

    private RequestStatisticsSample combineRequestStatistics(Long startTimestamp, int samplesInInterval,
                                                             List<RequestStatisticsSample> samples) {
        if (samples.isEmpty()) {
            return new RequestStatisticsSample(startTimestamp, 0, 0, 0, 0, 0);
        }

        double min = Double.MAX_VALUE, avg = 0, max = 0, rpm = 0;
        int count = 0;
        for (RequestStatisticsSample sample : samples) {
            count += sample.getCount();
            max = Math.max(max, sample.getMax());
            min = Math.min(min, sample.getMin());
            avg += sample.getCount() * sample.getAvg();
            rpm += sample.getRequestsPerMinute() / samplesInInterval;
        }
        return new RequestStatisticsSample(startTimestamp, count, rpm, min, count == 0 ? 0 : avg / count, max);
    }

    private <S extends Sample<S>> void streamSamples(DataStore dataStore, Date dateFrom, Date dateTo,
                                                     Operation operation, DataType type,
                                                     ThrowingFunction<DataInputStream, S, IOException> sampleReader,
                                                     SampleCallback<S> callback) throws IOException {
        Stream<Path> dataPaths = dataStore.streamPaths(dateFrom, dateTo, operation, type);

        dataPaths.forEach(path -> {
            try (DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(path.toFile())))) {
                int version = in.readInt();
                if (version != 1) {
                    // unsupported data file version
                    return;
                }
                DataFileHeaderV1 header = DataFileHeaderV1.readFrom(in);
                if (header != null) {
                    callback.setSampleInterval(TimeUnit.SECONDS.toMillis(header.getSampleIntervalSec()));
                }
                long start = dateFrom == null ? 0L : dateFrom.getTime();
                long end = dateTo == null ? Long.MAX_VALUE : dateTo.getTime();
                S sample;
                while ((sample = sampleReader.apply(in)) != null) {
                    if (sample.getTimestamp() < start || sample.getTimestamp() >= end) {
                        // out of scope
                        continue;
                    }

                    callback.onSample(sample);
                }
                callback.finish();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
    }

    private static class SampleInterpolatingCallback<S extends Sample<S>> implements SampleCallback<S> {
        private final SampleCombiner<S> combineFunction;
        private final Consumer<S> delegate;
        private final long outputIntervalSec;
        private final List<S> samples;

        private long inputIntervalMillis;
        private long curIntervalStart;
        private long nextIntervalStart;
        private int samplesInInterval;

        public SampleInterpolatingCallback(Consumer<S> delegate, SampleCombiner<S> combineFunction,
                                           long outputIntervalSec) {
            this.combineFunction = combineFunction;
            this.delegate = delegate;
            this.inputIntervalMillis = TimeUnit.MINUTES.toSeconds(1L);
            this.outputIntervalSec = outputIntervalSec;

            samples = new ArrayList<>();
            curIntervalStart = 0L;
            nextIntervalStart = 0L;
        }

        @Override
        public void onSample(S s) {
            long timestamp = s.getTimestamp();
            if (timestamp >= nextIntervalStart) {
                endInterval();

                while (nextIntervalStart < timestamp) {
                    curIntervalStart = curIntervalStart == 0 ? timestamp : nextIntervalStart;
                    nextIntervalStart = curIntervalStart + TimeUnit.SECONDS.toMillis(outputIntervalSec);
                    samplesInInterval = 0;
                    for (long t = curIntervalStart + inputIntervalMillis; t < nextIntervalStart; t += inputIntervalMillis) {
                        samplesInInterval++;
                    }
                }
            }
            samples.add(s);
        }

        public void finish() {
            endInterval();
        }

        @Override
        public void setSampleInterval(long intervalMillis) {
            inputIntervalMillis = intervalMillis;
        }

        private void endInterval() {
            if (!samples.isEmpty()) {
                delegate.accept(combineFunction.combine(curIntervalStart, samplesInInterval, samples));
                samples.clear();
            }
        }
    }

    /**
     * Callback that merges per-day problems
     */
    private static class ProblemMergingCallback implements SampleCallback<Problem> {

        private final Function<Problem, String> hashFunction;
        private final Consumer<Problem> consumer;
        private final Map<String, Problem> problemMap;

        private ProblemMergingCallback(Consumer<Problem> consumer, Function<Problem, String> hashFunction) {
            this.consumer = consumer;
            this.hashFunction = hashFunction;

            problemMap = new HashMap<>();
        }

        @Override
        public void onSample(Problem problem) throws IOException {
            problemMap.merge(hashFunction.apply(problem), problem,
                    (existing, newProblem) -> existing == null ? newProblem : existing.merge(newProblem));
        }

        @Override
        public void finish() throws IOException {
            List<Problem> problems = new ArrayList<>(problemMap.values());
            Collections.sort(problems);
            problems.forEach(consumer);
        }
    }

    @FunctionalInterface
    private interface SampleCombiner<S> {
        S combine(Long startTimestamp, int samplesInInterval, List<S> samples);
    }
}
