package com.atlassian.bitbucket.analyzer.internal.log.application;

import com.atlassian.bitbucket.analyzer.internal.log.AbstractLogParser;
import com.atlassian.bitbucket.analyzer.internal.log.ParserConfiguration;
import com.atlassian.bitbucket.analyzer.internal.log.sample.Sample;

import java.nio.file.Path;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StandardLogParser extends AbstractLogParser<StandardLogSample> {

    private static final String DATE_TIME = "(\\d{4}-\\d{2}-\\d{2}\\s+\\d{2}:\\d{2}:\\d{2},\\d{3})";
    private static final String LOG_LEVEL = "(TRACE|DEBUG|INFO|WARN|ERROR|FATAL)";
    private static final String THREAD = "\\[([^\\]]+)\\]";
    private static final String LOGGER_NAME = "([a-z]{1,4}\\.[\\w\\.]+)";
    // visible for testing
    static final Pattern LOG_FORMAT = Pattern.compile(
            DATE_TIME + " " + LOG_LEVEL + "\\s+" + THREAD + "(.*)\\s+" + LOGGER_NAME + "\\s+" + "(.+)"
    );
    private static final String EXCEPTION = "(\\w+(?:\\.\\w+)+):\\s+(.+)";
    // 2016-12-19 11:03:43,487 ERROR [http-nio-9080-exec-1] *1MJAF34x663x507963x2 172.30.210.137,172.24.12.146 "POST /rest/build-status/latest/commits/a8e6b2181f7dbf943f301c926d2c430acc462840 HTTP/1.0" c.a.s.i.build.dao.AoBuildStatusDao Multiple build statuses fo....
    // 2014-07-29 00:02:56,444 INFO  [AtlassianEvent::pool-3-thread-2] igerges @TZJAA6x2x387105x4 dyw4e0 172.24.36.105 SSH - git-receive-pack '/CONF/confluence.git' c.a.bitbucket.bamboo.RefUpdateNotifier ERROR MESSAGE
    private static final Pattern PATTERN_EXCEPTION = Pattern.compile(EXCEPTION);
    private StandardLogSample.Builder builder = null;
    private SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss,SSS");
    private boolean inExceptionMessage = false;
    private boolean inExceptionTrace = false;

    public StandardLogParser(ParserConfiguration configuration) {
        super(configuration);
    }

    @Override
    protected boolean includeFile(Path path) {
        String fileName = path.getFileName().toString();
        return (fileName.matches("atlassian-(bitbucket|stash)-20.*\\.log")) ||
                "atlassian-bitbucket.log".equals(fileName) || "atlassian-stash.log".equals(fileName);
    }

    @Override
    protected StandardLogSample onEof() {
        if (builder != null) {
            StandardLogSample sample = builder.build();
            builder = null;
            inExceptionMessage = inExceptionTrace = false;
            return sample;
        }
        return super.onEof();
    }

    @Override
    protected StandardLogSample toSample(String line) {
        line = line.trim();
        Matcher matcher = LOG_FORMAT.matcher(line);
        StandardLogSample result = null;
        if (matcher.matches()) {
            if (builder != null) {
                result = builder.build();
                inExceptionMessage = false;
                inExceptionTrace = false;
            }

            Date date = new Date();
            try {
                date = simpleDateFormat.parse(matcher.group(1));
            } catch (ParseException e) {
                e.printStackTrace();
            }
            builder = new StandardLogSample.Builder(date, Level.valueOf(matcher.group(2)), matcher.group(3), matcher.group(5));
            builder.appendMessage(matcher.group(6));
        } else {
            if (inExceptionMessage) {
                if (line.startsWith("at ") || line.startsWith("...") || line.startsWith("Caused by")) {
                    inExceptionMessage = false;
                    inExceptionTrace = true;
                }
            }
            if (inExceptionMessage) {
                builder.appendExceptionMessage(line);
            } else if (inExceptionTrace) {
                builder.stackFrame(line);
            } else if (builder != null) {
                Matcher exceptionMatcher = PATTERN_EXCEPTION.matcher(line);
                if (exceptionMatcher.matches()) {
                    inExceptionMessage = true;
                    builder.exception(exceptionMatcher.group(1), exceptionMatcher.group(2));
                } else {
                    builder.appendMessage(line);
                }
            }
        }

        return result;
    }
}
