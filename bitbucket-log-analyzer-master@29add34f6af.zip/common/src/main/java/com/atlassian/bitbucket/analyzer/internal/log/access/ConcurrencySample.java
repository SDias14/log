package com.atlassian.bitbucket.analyzer.internal.log.access;

import com.atlassian.bitbucket.analyzer.internal.log.sample.AbstractSample;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.io.*;

public class ConcurrencySample extends AbstractSample<ConcurrencySample> {
    private final double avg;
    private final int max;
    private final int min;

    public ConcurrencySample(long timestamp, int min, double avg, int max) {
        super(timestamp);
        this.avg = avg;
        this.max = max;
        this.min = min;
    }

    @Nullable
    public static ConcurrencySample readFrom(@Nonnull DataInputStream in) throws IOException {
        try {
            return new ConcurrencySample(in.readLong(), in.readInt(), in.readDouble(), in.readInt());
        } catch (EOFException e) {
            return null;
        }
    }

    public double getAvg() {
        return avg;
    }

    public int getMax() {
        return max;
    }

    public int getMin() {
        return min;
    }

    public void writeTo(DataOutputStream out) throws IOException {
        out.writeLong(getTimestamp());
        out.writeInt(min);
        out.writeDouble(avg);
        out.writeInt(max);
    }
}
