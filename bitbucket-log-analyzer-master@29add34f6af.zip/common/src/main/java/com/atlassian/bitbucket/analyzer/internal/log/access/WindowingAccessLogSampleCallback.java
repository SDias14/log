package com.atlassian.bitbucket.analyzer.internal.log.access;

import com.atlassian.bitbucket.analyzer.internal.log.callback.CallbackUtils;
import com.atlassian.bitbucket.analyzer.internal.log.callback.SampleCallback;

import java.io.IOException;
import java.util.LinkedList;
import java.util.ListIterator;

/**
 * Base implementation for {@link SampleCallback callbacks} for handling {@link AccessLogSample access log samples}.
 */
public class WindowingAccessLogSampleCallback implements SampleCallback<AccessLogSample> {

    private static final int MAX_IN_WINDOW = 1000;
    private static final int MAX_OUT_WINDOW = 20000;

    private final LinkedList<AccessLogSample> in = new LinkedList<>();
    private final LinkedList<AccessLogSample> out = new LinkedList<>();
    private final SampleCallback<AccessLogSample> delegate;

    private int count;
    private long newestTimestamp;

    public WindowingAccessLogSampleCallback(SampleCallback<AccessLogSample> delegate) {
        this.delegate = delegate;
    }

    @Override
    public void onSample(AccessLogSample sample) throws IOException {
        newestTimestamp = Math.max(sample.getStartDate().getTime(), newestTimestamp);
        if (sample.isOut()) {
            ListIterator<AccessLogSample> sampleIt = in.listIterator();
            boolean found = false;
            while (!found && sampleIt.hasNext()) {
                AccessLogSample s = sampleIt.next();
                found = (s.getRequestNumber() == sample.getRequestNumber() && s.getNodeId().equals(sample.getNodeId()));
                if (found) {
                    // replace the in-sample with the out-sample
                    long discrepancy = Math.abs(s.getStartDate().getTime() - sample.getStartDate().getTime());
                    if (discrepancy == 0L) {
                        // exactly where we expected it
                        sampleIt.set(sample);
                    } else {
                        if (discrepancy > 1000L) {
                            System.out.println("WARN: in and out samples don't agree on start date; discrepancy is " + discrepancy);
                        }
                        // update the start time to be the earliest of the two reported times
                        sample.getStartDate().setTime(Math.min(s.getStartDate().getTime(), sample.getStartDate().getTime()));
                    }
                    // removed it from the in list
                    sampleIt.remove();
                    CallbackUtils.insertInWindow(out, sample);
                }
            }

            if (found) {
                if (++count % 10000 == 0) {
                    System.out.println(sample.getStartDate() + " Processed " + count + " samples; buffered " +
                            in.size() + "," + out.size() + " samples");
                }
            }
        } else {
            CallbackUtils.insertInWindow(in, sample);
        }

        // trim the in buffer
        while (in.size() > MAX_IN_WINDOW) {
            dropOldestInSample();
        }

        do {
            AccessLogSample wanted = in.peek();
            while (!out.isEmpty()) {
                AccessLogSample found = out.peek();
                if (wanted != null && wanted.getStartDate().before(found.getStartDate())) {
                    // head of out cannot be emitted yet because the head of in is older
                    break;
                }
                found = out.pop();
                delegate.onSample(found);
            }

            if (out.size() > MAX_OUT_WINDOW) {
                dropOldestInSample();
            }
        } while (out.size() > MAX_OUT_WINDOW);
    }

    @Override
    public void finish() throws IOException {
        while (!out.isEmpty()) {
            delegate.onSample(out.pop());
        }
        if (!in.isEmpty()) {
            System.out.println("Discarded " + in.size() + " samples that hadn't completed yet");
        }

        delegate.finish();
    }

    @Override
    public void start() throws IOException {
        delegate.start();
    }

    private void dropOldestInSample() {
        if (!in.isEmpty()) {
            AccessLogSample head = in.pop();
            System.out.println("Cannot find matching out request for " + head + "; ignoring the request");
        }
    }
}
