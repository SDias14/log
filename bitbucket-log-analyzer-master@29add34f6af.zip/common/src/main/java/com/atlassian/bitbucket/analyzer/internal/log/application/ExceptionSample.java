package com.atlassian.bitbucket.analyzer.internal.log.application;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Represents an entry from the application log that has an associated stack trace
 */
public class ExceptionSample {
    private final String className;
    private final String message;
    private final List<String> stackTrace;

    public ExceptionSample(String className, String message, List<String> stackTrace) {
        this.className = className;
        this.message = message;
        this.stackTrace = stackTrace;
    }

    public static ExceptionSample readFrom(DataInputStream in) throws IOException {
        String className = in.readUTF();
        String message = in.readUTF();
        int frameCount = in.readInt();
        List<String> frames = new ArrayList<>(frameCount);
        for (int i = 0; i < frameCount; ++i) {
            frames.add(in.readUTF());
        }
        return new ExceptionSample(className, message, frames);
    }

    public String getClassName() {
        return className;
    }

    public String getMessage() {
        return message;
    }

    public List<String> getStackTrace() {
        return stackTrace;
    }

    public String toString() {
        StringBuilder builder = new StringBuilder("{")
                .append("class: ").append(className)
                .append(", message: '").append(message).append("'")
                .append(", stacktrace: [");
        for (String frame : stackTrace) {
            builder.append("\n\t\"").append(frame).append("\",");
        }
        return builder.append("]}").toString();
    }

    public void writeTo(DataOutputStream out) throws IOException {
        out.writeUTF(className);
        out.writeUTF(message);
        out.writeInt(stackTrace.size());
        for (String line : stackTrace) {
            out.writeUTF(line);
        }
    }
}
