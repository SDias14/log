package com.atlassian.bitbucket.analyzer.internal.log.sample;

public interface RequestSample<T extends RequestSample<T>> extends Sample<T> {
    Integer getDuration();
}
