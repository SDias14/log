package com.atlassian.bitbucket.analyzer.internal.log.application;

import com.atlassian.bitbucket.analyzer.internal.log.ParserConfiguration;
import com.atlassian.bitbucket.analyzer.internal.log.callback.DataOutputStreamProvider;
import com.atlassian.bitbucket.analyzer.internal.log.store.DataType;

import java.util.function.Predicate;

public class ApplicationLogUtils {

    public static Predicate<StandardLogSample> infoAndHigher() {
        return sample -> sample.getLevel().severity >= Level.INFO.severity;
    }

    public static Predicate<StandardLogSample> warnAndHigher() {
        return sample -> sample.getLevel() == Level.ERROR || sample.getLevel() == Level.WARN ||
                sample.getLevel() == Level.FATAL;
    }

    public static DataOutputStreamProvider outputProvider(ParserConfiguration configuration) {
        return new DataOutputStreamProvider(configuration, DataType.PROBLEMS);
    }

}
