package com.atlassian.bitbucket.analyzer.internal.log;

@FunctionalInterface
public interface ThrowingConsumer<T, E extends Exception> {
    void accept(T value) throws E;
}
