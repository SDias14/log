package com.atlassian.bitbucket.analyzer.internal.log;

import javax.annotation.Nonnull;
import java.io.*;
import java.util.Properties;

public class AnalyzerConfig {

    private static final String PROP_DATA_DIRECTORY = "data.directory";

    private File dataDirectory;

    public static AnalyzerConfig load() {
        AnalyzerConfig config = new AnalyzerConfig();
        File configFile = getConfigFile();
        if (configFile.exists()) {
            try (InputStream inputStream = new FileInputStream(configFile)) {
                Properties properties = new Properties();
                properties.load(inputStream);
                String dataDir = properties.getProperty(PROP_DATA_DIRECTORY);
                if (dataDir != null) {
                    config.setDataDirectory(new File(dataDir));
                }
            } catch (IOException e) {
                // ignore
            }
        }
        return config;
    }

    public File getDataDirectory() {
        return dataDirectory;
    }

    public void setDataDirectory(@Nonnull File dataDirectory) {
        this.dataDirectory = dataDirectory;
    }

    public void store() {
        File configFile = getConfigFile();
        Properties properties = new Properties();
        properties.setProperty(PROP_DATA_DIRECTORY, dataDirectory.getAbsolutePath());
        try (OutputStream outputStream = new FileOutputStream(configFile)) {
            properties.store(outputStream, "Bitbucket Server Log Analyzer settings");
        } catch (IOException e) {
            // ignore
        }
    }


    private static File getConfigFile() {
        return new File(System.getProperty("user.home") + "/.bbanalyzer.properties");
    }
}
