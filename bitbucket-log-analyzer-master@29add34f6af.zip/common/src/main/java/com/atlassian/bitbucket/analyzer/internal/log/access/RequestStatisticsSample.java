package com.atlassian.bitbucket.analyzer.internal.log.access;

import com.atlassian.bitbucket.analyzer.internal.log.sample.AbstractSample;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;

public class RequestStatisticsSample extends AbstractSample<RequestStatisticsSample> {

    private final double avg;
    private final int count;
    private final double max;
    private final double min;
    private final double requestsPerMinute;

    public RequestStatisticsSample(long timestamp, int count, double rpm, double min, double avg, double max) {
        super(timestamp);

        this.avg = avg;
        this.count = count;
        this.max = max;
        this.min = min;
        this.requestsPerMinute = rpm;
    }

    @Nullable
    public static RequestStatisticsSample readFrom(@Nonnull DataInputStream in) throws IOException {
        try {
            return new RequestStatisticsSample(in.readLong(), in.readInt(), in.readDouble(),
                    in.readDouble(), in.readDouble(), in.readDouble());
        } catch (EOFException e) {
            return null;
        }
    }

    public double getAvg() {
        return avg;
    }

    public int getCount() {
        return count;
    }

    public double getMax() {
        return max;
    }

    public double getMin() {
        return min;
    }

    public double getRequestsPerMinute() {
        return requestsPerMinute;
    }

    public void writeTo(@Nonnull DataOutputStream out) throws IOException {
        out.writeLong(getTimestamp());
        out.writeInt(count);
        out.writeDouble(requestsPerMinute);
        out.writeDouble(min);
        out.writeDouble(avg);
        out.writeDouble(max);
    }
}
