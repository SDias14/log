package com.atlassian.bitbucket.analyzer.internal.log.application;

import com.atlassian.bitbucket.analyzer.internal.log.sample.Sample;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class Problem implements Sample<Problem>, Comparable<Problem> {
    private final List<Date> occurrences;
    private final StandardLogSample sample;

    Problem(StandardLogSample sample, List<Date> occurrences) {
        this.sample = sample;
        this.occurrences = occurrences;
    }

    Problem(StandardLogSample sample) {
        this.sample = sample;
        this.occurrences = new ArrayList<>();

        occurrences.add(sample.getDate());
    }

    public static Problem readFrom(DataInputStream in) throws IOException {
        try {
            int size = in.readInt();
            List<Date> occurrences = new ArrayList<>(size);
            for (int i = 0; i < size; ++i) {
                occurrences.add(new Date(in.readLong()));
            }
            StandardLogSample sample = StandardLogSample.readFrom(in);
            return new Problem(sample, occurrences);
        } catch (EOFException e) {
            return null;
        }
    }

    public String calculateHash() {
        return sample.calculateHash();
    }

    public int getCount() {
        return occurrences.size();
    }

    public ExceptionSample getException() {
        return sample.getException();
    }

    public Level getLevel() {
        return sample.getLevel();
    }

    public String getMessage() {
        return sample.getMessage();
    }

    public long getTimestampFirst() {
        return occurrences.get(0).getTime();
    }

    public long getTimestampLast() {
        return occurrences.get(occurrences.size() - 1).getTime();
    }

    @Override
    public long getTimestamp() {
        return sample.getTimestamp();
    }

    public Problem merge(Problem other) {
        List<Date> merged = new ArrayList<>(occurrences.size() + other.occurrences.size());
        merged.addAll(occurrences);
        merged.addAll(other.occurrences);
        Collections.sort(merged);
        return new Problem(sample, merged);
    }

    public void writeTo(DataOutputStream out) throws IOException {
        out.writeInt(occurrences.size());
        for (Date date : occurrences) {
            out.writeLong(date.getTime());
        }
        sample.writeTo(out);
    }

    void add(StandardLogSample sample) {
        occurrences.add(sample.getDate());
    }

    public String toString() {
        return sample + " occurred " + occurrences.size() + " times";
    }

    @Override
    public int compareTo(Problem o) {
        int result = o.sample.getLevel().severity - sample.getLevel().severity;
        if (result == 0) {
            result = o.occurrences.size() - occurrences.size();
        }
        return result;
    }
}
