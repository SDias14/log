package com.atlassian.bitbucket.analyzer.internal.log.application;

import com.atlassian.bitbucket.analyzer.internal.log.sample.Sample;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

public class StandardLogSample implements Sample<StandardLogSample>, Comparable<StandardLogSample> {

    private final Date date;
    private final ExceptionSample exceptionSample;
    private final Level level;
    private final String loggerName;
    private final String message;
    private final String threadName;

    public StandardLogSample(Date date, Level level, String threadName, String loggerName, String message, ExceptionSample exceptionSample) {
        this.date = date;
        this.exceptionSample = exceptionSample;
        this.level = level;
        this.loggerName = loggerName;
        this.message = message;
        this.threadName = threadName;
    }

    @Nullable
    public static StandardLogSample readFrom(@Nonnull DataInputStream in) throws IOException {
        try {
            StandardLogSample.Builder builder = new StandardLogSample.Builder(
                    new Date(in.readLong()), Level.valueOf(in.readUTF()), in.readUTF(), in.readUTF())
                    .appendMessage(in.readUTF());

            if (in.readBoolean()) {
                // has an exception
                builder.exception(ExceptionSample.readFrom(in));
            }

            return builder.build();
        } catch (EOFException e) {
            return null;
        }
    }

    public String calculateHash() {
        try {
            Charset cs = Charset.forName("UTF-8");
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            Optional<String> knownIssueHash = KnownIssuesHasher.getHash(message);
            if (knownIssueHash.isPresent()) {
                digest.update(knownIssueHash.get().getBytes(cs));
            } else if (exceptionSample != null) {
                digest.update(exceptionSample.getClassName().getBytes(cs));
                for (String stackFrame : exceptionSample.getStackTrace()) {
                    digest.update(stackFrame.getBytes(cs));
                }
            } else {
                // no exception, just hash the message
                String hashSource = generify(message);
                digest.update(hashSource.getBytes(cs));
            }

            return toHex(digest.digest());
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public int compareTo(StandardLogSample o) {
        return date.compareTo(o.date);
    }

    public Date getDate() {
        return date;
    }

    public long getTimestamp() {
        return date.getTime();
    }

    public ExceptionSample getException() {
        return exceptionSample;
    }

    public Level getLevel() {
        return level;
    }

    public String getMessage() {
        return message;
    }

    public String getThreadName() {
        return threadName;
    }

    public String toString() {
        StringBuilder result = new StringBuilder("{date: ").append(date)
                .append(", level: ").append(level.name())
                .append(", thread: ").append(threadName)
                .append(", logger: ").append(loggerName)
                .append(", message: '").append(message).append("'");

        if (exceptionSample != null) {
            result.append(", exception: ").append(exceptionSample);
        }

        return result.append("\n}").toString();
    }

    public void writeTo(@Nonnull DataOutputStream out) throws IOException {
        out.writeLong(date.getTime());
        out.writeUTF(level.name());
        out.writeUTF(threadName);
        out.writeUTF(loggerName);
        out.writeUTF(message);
        if (exceptionSample != null) {
            out.writeBoolean(true);
            exceptionSample.writeTo(out);
        } else {
            out.writeBoolean(false);
        }
    }

    private static String generify(String message) {
        // strip anything between '', "" and []
        return message.replaceAll("('[^']*')|(\"[^\"]*\")|(\\[[^\\]]*\\])", "");
    }

    private static String toHex(byte[] bytes) {
        StringBuilder hex = new StringBuilder();

        for (byte b : bytes) {
            int intRep = b & 0xFF;
            if (intRep < 0x10) {
                // add leading zero
                hex.append('\u0030');
            }
            hex.append(Integer.toHexString(intRep));
        }

        return hex.toString();
    }

    public static class Builder {
        private final Date date;
        private final Level level;
        private final String loggerName;
        private final String threadName;
        private final StringBuilder message;
        private String exceptionClass;
        private StringBuilder exceptionMessage;
        private List<String> stackFrames;

        public Builder(Date date, Level level, String threadName, String loggerName) {
            this.date = date;
            this.level = level;
            this.loggerName = loggerName;
            this.threadName = threadName;

            exceptionMessage = new StringBuilder();
            message = new StringBuilder();
            stackFrames = new ArrayList<>();
        }

        public Builder appendExceptionMessage(String value) {
            exceptionMessage.append(value);
            return this;
        }

        Builder appendMessage(String value) {
            if (message.length() > 0) {
                message.append("\n");
            }
            message.append(value);
            return this;
        }

        StandardLogSample build() {
            return new StandardLogSample(date, level, threadName, loggerName, message.toString(), buildException());
        }

        Builder exception(String exceptionClass, String message) {
            this.exceptionClass = exceptionClass;
            this.exceptionMessage = new StringBuilder(message);
            return this;
        }

        Builder exception(ExceptionSample exception) {
            this.exceptionClass = exception.getClassName();
            this.exceptionMessage.append(exception.getMessage());
            this.stackFrames = exception.getStackTrace();
            return this;
        }

        Builder stackFrame(String line) {
            stackFrames.add(line);
            return this;
        }

        private ExceptionSample buildException() {
            return exceptionClass == null ? null : new ExceptionSample(exceptionClass, exceptionMessage.toString(), stackFrames);
        }
    }
}
