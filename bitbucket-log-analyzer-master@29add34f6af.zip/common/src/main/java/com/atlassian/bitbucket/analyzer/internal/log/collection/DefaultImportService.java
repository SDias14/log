package com.atlassian.bitbucket.analyzer.internal.log.collection;

import com.atlassian.bitbucket.analyzer.internal.log.ParserConfiguration;
import com.atlassian.bitbucket.analyzer.internal.log.access.AccessLogParser;
import com.atlassian.bitbucket.analyzer.internal.log.access.AccessLogSample;
import com.atlassian.bitbucket.analyzer.internal.log.access.WindowingAccessLogSampleCallback;
import com.atlassian.bitbucket.analyzer.internal.log.application.StandardLogParser;
import com.atlassian.bitbucket.analyzer.internal.log.application.StandardLogSample;
import com.atlassian.bitbucket.analyzer.internal.log.application.UniqueProblemCallback;
import com.atlassian.bitbucket.analyzer.internal.log.callback.IntervalStatsCallback;
import com.atlassian.bitbucket.analyzer.internal.log.callback.SampleCallback;
import com.atlassian.bitbucket.analyzer.internal.log.sample.Sample;

import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import static com.atlassian.bitbucket.analyzer.internal.log.Operation.*;
import static com.atlassian.bitbucket.analyzer.internal.log.access.AccessLogUtils.cacheRatioTracker;
import static com.atlassian.bitbucket.analyzer.internal.log.access.AccessLogUtils.concurrencyTracker;
import static com.atlassian.bitbucket.analyzer.internal.log.access.AccessLogUtils.requestStatisticsTracker;
import static com.atlassian.bitbucket.analyzer.internal.log.application.ApplicationLogUtils.*;

public class DefaultImportService implements ImportService {

    private final ExecutorService executorService;

    public DefaultImportService(ExecutorService executorService) {
        this.executorService = executorService;
    }

    @Override
    public Future<ImportDetails> startImport(ImportRequest request) throws IOException {
        ParserConfiguration configuration = new ParserConfiguration.Builder()
                .logFileDirectory(request.getLogDirectory())
                .dataStore(request.getDataStore())
                .sampleInterval(request.getSampleInterval(), TimeUnit.SECONDS)
                .build();

        IntervalStatsCallback<AccessLogSample> intervalCallback = new IntervalStatsCallback<>(configuration);
        if (request.isGeneralStatistics()) {
            request.getOperations().stream()
                    .map(op -> requestStatisticsTracker(op, configuration))
                    .forEach(intervalCallback::track);
        }
        if (request.isConcurrency()) {
            request.getOperations().stream()
                    .map(op -> concurrencyTracker(op, configuration))
                    .forEach(intervalCallback::track);
        }
        if (request.isCacheRatio()) {
            request.getOperations().stream()
                    .filter(op -> op.inInCategory(HOSTING))
                    .map(op -> cacheRatioTracker(op, configuration))
                    .forEach(intervalCallback::track);
        }

        ImportDetails.Builder resultBuilder = new ImportDetails.Builder();
        intervalCallback.track(resultBuilder::addSample);

        AccessLogParser accessLogParser = new AccessLogParser(configuration);
        WindowingAccessLogSampleCallback accessLogCallback = new WindowingAccessLogSampleCallback(intervalCallback);

        StandardLogParser standardLogParser = new StandardLogParser(configuration);
        UniqueProblemCallback standardLogCallback = new UniqueProblemCallback(infoAndHigher(), outputProvider(configuration));
        SampleCallback<StandardLogSample> countingCallback = resultBuilder::addSample;

        return executorService.submit(() -> {
            accessLogParser.parse(accessLogCallback);
            standardLogParser.parse(standardLogCallback, countingCallback);
            return resultBuilder.build();
        });
    }
}
