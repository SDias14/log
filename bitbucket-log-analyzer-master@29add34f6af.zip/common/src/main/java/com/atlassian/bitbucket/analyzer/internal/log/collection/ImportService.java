package com.atlassian.bitbucket.analyzer.internal.log.collection;

import java.io.IOException;
import java.util.concurrent.Future;

public interface ImportService {
    Future<ImportDetails> startImport(ImportRequest request) throws IOException;
}
