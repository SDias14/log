package com.atlassian.bitbucket.analyzer.internal.log.collection;

import com.atlassian.bitbucket.analyzer.internal.log.Operation;
import com.atlassian.bitbucket.analyzer.internal.log.access.CacheRatioSample;
import com.atlassian.bitbucket.analyzer.internal.log.access.ConcurrencySample;
import com.atlassian.bitbucket.analyzer.internal.log.access.RequestStatisticsSample;
import com.atlassian.bitbucket.analyzer.internal.log.application.Problem;
import com.atlassian.bitbucket.analyzer.internal.log.store.DataStore;

import java.io.IOException;
import java.util.Date;
import java.util.function.Consumer;
import java.util.function.Function;

public interface DataService {
    void streamCacheRatio(DataStore store, Date fromDate, Date toDate, int interval, Operation operation,
                          Consumer<CacheRatioSample> callback) throws IOException;

    void streamConcurrency(DataStore dataStore, Date dateFrom, Date dateTo, int intervalMinute, Operation operation,
                           Consumer<ConcurrencySample> callback) throws IOException;

    void streamProblems(DataStore dataStore, Date dateFrom, Date dateTo, Function<Problem, String> groupFunction,
                        Consumer<Problem> callback) throws IOException;

    void streamRequestStatistics(DataStore store, Date fromDate, Date toDate, int interval, Operation operation,
                                 Consumer<RequestStatisticsSample> callback) throws IOException;
}
