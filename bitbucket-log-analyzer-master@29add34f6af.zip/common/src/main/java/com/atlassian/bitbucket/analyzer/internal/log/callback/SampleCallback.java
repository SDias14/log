package com.atlassian.bitbucket.analyzer.internal.log.callback;

import java.io.IOException;

@FunctionalInterface
public interface SampleCallback<S> {

    void onSample(S sample) throws IOException;

    default void setSampleInterval(long intervalMillis) {
    }

    default void start() throws IOException {
    }

    default void finish() throws IOException {
    }
}
