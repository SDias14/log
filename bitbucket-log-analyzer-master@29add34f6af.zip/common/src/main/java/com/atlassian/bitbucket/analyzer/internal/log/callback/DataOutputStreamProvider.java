package com.atlassian.bitbucket.analyzer.internal.log.callback;

import com.atlassian.bitbucket.analyzer.internal.log.DataFileHeaderV1;
import com.atlassian.bitbucket.analyzer.internal.log.Operation;
import com.atlassian.bitbucket.analyzer.internal.log.ParserConfiguration;
import com.atlassian.bitbucket.analyzer.internal.log.store.DataStore;
import com.atlassian.bitbucket.analyzer.internal.log.store.DataType;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Date;
import java.util.function.Consumer;

public class DataOutputStreamProvider implements AutoCloseable {

    private final ParserConfiguration configuration;
    private final DataType dataType;
    private final DataFileHeaderV1 header;
    private final Operation operation;

    private Consumer<DataOutputStream> beforeCloseCallback;
    private DataOutputStream outputStream;
    private Path path;

    public DataOutputStreamProvider(ParserConfiguration configuration, DataType dataType) {
        this(configuration, dataType, null);
    }

    public DataOutputStreamProvider(ParserConfiguration configuration, DataType dataType, Operation operation) {
        this.configuration = configuration;
        this.dataType = dataType;
        this.operation = operation;

        header = new DataFileHeaderV1(configuration.getSampleIntervalSec());
    }

    public void onBeforeClose(Consumer<DataOutputStream> callback) {
        beforeCloseCallback = callback;
    }

    public void close() {
        if (outputStream != null) {
            try {
                if (beforeCloseCallback != null) {
                    beforeCloseCallback.accept(outputStream);
                }
            } catch (Exception e) {
                // ignore
            }
            try {
                outputStream.close();
            } catch (IOException e) {
                // ignore
            }
            outputStream = null;
        }
    }

    public DataOutputStream get(Date date) throws IOException {
        DataStore store = configuration.getDataStore();
        Path datePath = operation == null ? store.getPath(date, dataType) : store.getPath(date, operation, dataType);
        if (!datePath.equals(path)) {
            close();

            path = datePath;

            Files.createDirectories(path.getParent());
            outputStream = new DataOutputStream(new FileOutputStream(path.toFile()));
            outputStream.writeInt(header.getVersion());
            header.writeTo(outputStream);
        }
        return outputStream;
    }
}
