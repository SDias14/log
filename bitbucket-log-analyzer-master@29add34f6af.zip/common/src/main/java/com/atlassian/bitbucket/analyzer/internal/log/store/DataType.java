package com.atlassian.bitbucket.analyzer.internal.log.store;

public enum DataType {
    CACHE_RATIO("cache-ratio"),
    CONCURRENCY("concurrency"),
    PROBLEMS("problems"),
    REQUEST_STATISTICS("request-statistics");

    private String id;
    DataType(String id) {
        this.id = id;
    }

    public static DataType fromId(String id) {
        for (DataType type : values()) {
            if (type.getId().equalsIgnoreCase(id) || type.name().equalsIgnoreCase(id)) {
                return type;
            }
        }
        throw new IllegalArgumentException("No DataType exists with id " + id);
    }

    public String getId() {
        return id;
    }
}
