package com.atlassian.bitbucket.analyzer.internal.log.access;

import com.atlassian.bitbucket.analyzer.internal.log.sample.AbstractSample;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;

public class CacheRatioSample extends AbstractSample<CacheRatioSample> {

    private final int hits;
    private final int misses;
    private final int other;

    public CacheRatioSample(long timestamp, int hits, int misses, int other) {
        super(timestamp);

        this.hits = hits;
        this.misses = misses;
        this.other = other;
    }

    @Nullable
    public static CacheRatioSample readFrom(@Nonnull DataInputStream in) throws IOException {
        try {
            return new CacheRatioSample(in.readLong(), in.readInt(), in.readInt(), in.readInt());
        } catch (EOFException e) {
            return null;
        }
    }

    public int getHits() {
        return hits;
    }

    public int getMisses() {
        return misses;
    }

    public int getOther() {
        return other;
    }

    public void writeTo(@Nonnull DataOutputStream out) throws IOException {
        out.writeLong(getTimestamp());
        out.writeInt(hits);
        out.writeInt(misses);
        out.writeInt(other);
    }
}
