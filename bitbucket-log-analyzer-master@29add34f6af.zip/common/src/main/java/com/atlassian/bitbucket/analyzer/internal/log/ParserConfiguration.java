package com.atlassian.bitbucket.analyzer.internal.log;

import com.atlassian.bitbucket.analyzer.internal.log.store.DataStore;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.io.File;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import static java.util.Objects.requireNonNull;

/**
 * Parser configuration class
 */
public class ParserConfiguration {
    private final DataStore dataStore;
    private final Date fromDate;
    private final Path logFileDirectory;
    private final Set<String> repositories;
    private final long sampleIntervalSecs;
    private final Date toDate;
    private final Function<Long, Boolean> withinBound;

    private ParserConfiguration(Builder builder) {
        dataStore = builder.dataStore;
        fromDate = builder.fromDate;
        logFileDirectory = builder.logFileDirectory;
        sampleIntervalSecs = builder.sampleIntervalSec;
        repositories = new HashSet<>(builder.repos);
        toDate = builder.toDate;

        if (fromDate != null && toDate != null) {
            withinBound = time -> time >= fromDate.getTime() &&
                    time <= toDate.getTime();
        } else if (fromDate != null) {
            withinBound = time -> time >= fromDate.getTime();
        } else if (toDate != null) {
            withinBound = time -> time <= toDate.getTime();
        } else {
            withinBound = sample -> true;
        }
    }

    public DataStore getDataStore() {
        return dataStore;
    }

    public Date getFromDate() {
        return fromDate;
    }

    public Path getLogFileDirectory() {
        return logFileDirectory;
    }

    public long getSampleIntervalSec() {
        return sampleIntervalSecs;
    }

    public Date getToDate() {
        return toDate;
    }

    public Set<String> getRepositories() {
        return Collections.unmodifiableSet(repositories);
    }

    public boolean withinBounds(Date time) {
        return withinBound.apply(time.getTime());
    }

    public boolean withinBounds(long time) {
        return withinBound.apply(time);
    }

    public static class Builder {
        private DataStore dataStore;
        private Date fromDate;
        private Path logFileDirectory;
        private Set<String> repos;
        private long sampleIntervalSec;
        private Date toDate;

        public Builder() {
            repos = new HashSet<>();
            sampleIntervalSec = TimeUnit.MINUTES.toSeconds(15);
        }

        @Nonnull
        public ParserConfiguration build() {
            return new ParserConfiguration(this);
        }

        @Nonnull
        public Builder dataStore(@Nonnull DataStore value) {
            dataStore = requireNonNull(value, "dataStore");
            return this;
        }

        @Nonnull
        public Builder logFileDirectory(@Nonnull Path value) {
            logFileDirectory = requireNonNull(value, "logFileDirectory");
            return this;
        }

        @Nonnull
        public Builder period(@Nullable Date from, @Nullable Date to) {
            fromDate = from;
            toDate = to;
            return this;
        }

        @Nonnull
        public Builder repository(@Nonnull String value) {
            repos.add(requireNonNull(value, "repository"));
            return this;
        }

        @Nonnull
        public Builder sampleInterval(long time, @Nonnull TimeUnit timeUnit) {
            sampleIntervalSec = timeUnit.toSeconds(time);
            return this;
        }
    }
}
