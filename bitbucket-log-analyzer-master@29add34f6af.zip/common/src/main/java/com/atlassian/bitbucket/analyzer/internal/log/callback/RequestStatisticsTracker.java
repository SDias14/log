package com.atlassian.bitbucket.analyzer.internal.log.callback;

import com.atlassian.bitbucket.analyzer.internal.log.access.RequestStatisticsSample;
import com.atlassian.bitbucket.analyzer.internal.log.sample.RequestSample;

import java.io.*;
import java.util.Date;
import java.util.function.Predicate;

public class RequestStatisticsTracker<S extends RequestSample<S>> implements IntervalTracker<S> {
    private final Predicate<S> includePredicate;
    private final DataOutputStreamProvider outputProvider;

    private int count;
    private int minDuration;
    private double sumDuration;
    private int maxDuration;

    public RequestStatisticsTracker(Predicate<S> includePredicate, DataOutputStreamProvider outputProvider) {
        this.includePredicate = includePredicate;
        this.outputProvider = outputProvider;
    }

    @Override
    public void finish() throws IOException {
        outputProvider.close();
    }

    @Override
    public void start() throws IOException {
    }

    @Override
    public void write(Date intervalStart, Date intervalEnd) throws IOException {
        double rpm = count / ((intervalEnd.getTime() - intervalStart.getTime()) / 60000.0);
        if (count > 0) {
            double avg = sumDuration / count;

            new RequestStatisticsSample(intervalStart.getTime(), count, rpm, minDuration, avg, maxDuration)
                    .writeTo(outputProvider.get(intervalStart));
        }

        count = 0;
        minDuration = -1;
        maxDuration = -1;
        sumDuration = 0.0d;
    }

    @Override
    public void onSample(S sample) {
        if (isIncluded(sample)) {
            ++count;
            minDuration = (minDuration > 0 ? Math.min(sample.getDuration(), minDuration) : sample.getDuration());
            maxDuration = (maxDuration > 0 ? Math.max(sample.getDuration(), maxDuration) : sample.getDuration());
            sumDuration += sample.getDuration();
        }
    }

    @Override
    public void onStart(long firstIntervalStart, long intervalSize) {
        // ignore
    }

    protected boolean isIncluded(S sample) {
        return sample.getDuration() != null && includePredicate.test(sample);
    }
}
