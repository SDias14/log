package com.atlassian.bitbucket.analyzer.internal.log.store;

import com.atlassian.bitbucket.analyzer.internal.log.Operation;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Stream;

public class DataStore {
    private static final String DIR_FORMAT = "yyyy-MM-dd";

    private final SimpleDateFormat dateFormat;
    private final Path location;

    public DataStore(Path location) {
        this.location = location;

        dateFormat = new SimpleDateFormat(DIR_FORMAT);
    }

    public List<LocalDate> getAvailableDates(LocalDate sinceDate) {
        List<LocalDate> dates = new ArrayList<>();
        try {
            Files.list(location)
                    .forEach(path -> {
                        try {
                            LocalDate date = LocalDate.parse(path.getFileName().toString());
                            if (sinceDate == null || date.isAfter(sinceDate)) {
                                dates.add(date);
                            }
                        } catch (DateTimeParseException e) {
                            // ignore
                        }
                    });
        } catch (IOException e) {
            // ignore
        }
        return dates;
    }

    public Path getPath(Date date, Operation operation, DataType type) {
        return location.resolve(getDirName(date)).resolve(getDataFileName(operation, type));
    }

    public Path getPath(Date date, DataType type) {
        return getPath(date, null, type);
    }

    public Stream<Path> streamPaths(Date dateFrom, Date dateTo, Operation operation, DataType type) {
        SimpleDateFormat dirFormat = new SimpleDateFormat(DIR_FORMAT);
        String dataFileName = getDataFileName(operation, type);
        try {
            return Files.list(location)
                    .filter(path -> inScope(dirFormat, path, dateFrom, dateTo))
                    .sorted()
                    .map(path -> path.resolve(dataFileName))
                    .filter(path -> path.toFile().exists());
        } catch (IOException e) {
            return Collections.<Path>emptyList().stream();
        }
    }

    private String getDataFileName(Operation operation, DataType type) {
        switch (type) {
            case PROBLEMS:
                return type.getId() + ".bin";
            default:
                return operation == null ? "total" : operation.getId() + "_" + type.getId() + ".bin";
        }
    }

    private String getDirName(Date date) {
        synchronized (dateFormat) {
            return dateFormat.format(date);
        }
    }

    private boolean inScope(DateFormat dirFormat, Path path, Date from, Date to) {
        if (!path.toFile().isDirectory()) {
            return false;
        }

        try {
            Date dirDate = dirFormat.parse(path.getFileName().toString());
            return (from == null || !dirDate.before(from)) && (to == null || dirDate.before(to));
        } catch (ParseException e) {
            return false;
        }
    }
}
