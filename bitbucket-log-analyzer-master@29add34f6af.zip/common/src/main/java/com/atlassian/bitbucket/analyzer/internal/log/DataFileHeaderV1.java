package com.atlassian.bitbucket.analyzer.internal.log;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;

public class DataFileHeaderV1 {
    private final long sampleIntervalSec;

    public DataFileHeaderV1(long sampleIntervalSec) {
        this.sampleIntervalSec = sampleIntervalSec;
    }

    @Nullable
    public static DataFileHeaderV1 readFrom(@Nonnull DataInputStream in) throws IOException {
        try {
            return new DataFileHeaderV1(in.readLong());
        } catch (EOFException e) {
            return null;
        }
    }

    public long getSampleIntervalSec() {
        return sampleIntervalSec;
    }

    public int getVersion() {
        return 1;
    }

    public void writeTo(@Nonnull DataOutputStream out) throws IOException {
        out.writeLong(sampleIntervalSec);
    }
}
