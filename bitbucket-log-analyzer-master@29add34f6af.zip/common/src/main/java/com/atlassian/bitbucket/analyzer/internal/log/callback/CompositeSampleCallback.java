package com.atlassian.bitbucket.analyzer.internal.log.callback;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CompositeSampleCallback<T> implements SampleCallback<T> {

    private final List<SampleCallback<T>> callbacks = new ArrayList<>();

    public CompositeSampleCallback(SampleCallback<T>... callbacks) {
        this.callbacks.addAll(Arrays.asList(callbacks));
    }

    public static <T> CompositeSampleCallback<T> of(SampleCallback<T>...callbacks) {
        return new CompositeSampleCallback<>(callbacks);
    }

    public void addCallback(SampleCallback<T> callback) {
        callbacks.add(callback);
    }

    @Override
    public void onSample(T sample) throws IOException {
        for (SampleCallback<T> callback : callbacks) {
            callback.onSample(sample);
        }
    }

    @Override
    public void start() throws IOException {
        for (SampleCallback<T> callback : callbacks) {
            callback.start();
        }
    }

    @Override
    public void finish() throws IOException {
        for (SampleCallback<T> callback : callbacks) {
            callback.finish();
        }
    }
}
