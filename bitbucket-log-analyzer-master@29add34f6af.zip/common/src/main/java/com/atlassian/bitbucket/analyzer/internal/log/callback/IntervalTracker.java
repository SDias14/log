package com.atlassian.bitbucket.analyzer.internal.log.callback;

import java.io.IOException;
import java.util.Date;

public interface IntervalTracker<S> {

    default void start() throws IOException {}

    default void finish() throws IOException {}

    void onSample(S sample);

    default void onStart(long firstIntervalStart, long intervalSize) {}

    default void write(Date intervalStart, Date intervalEnd) throws IOException {}
}
