package com.atlassian.bitbucket.analyzer.internal.log.collection;

import java.nio.file.Path;
import java.util.Date;
import java.util.List;

/**
 * Represents a collection of logs that belong together. For instance, logs from the same customer or logs from a
 * support issue.
 */
public class LogCollection {
    private final String name;
    private final Path path;
    private final Date newest;
    private final Date oldest;

    public LogCollection(String name, Path path, Date oldest, Date newest) {
        this.name = name;
        this.newest = newest;
        this.oldest = oldest;
        this.path = path;
    }

    public String getName() {
        return name;
    }

    public Date getNewest() {
        return newest;
    }

    public Date getOldest() {
        return oldest;
    }

    public Path getPath() {
        return path;
    }


}
