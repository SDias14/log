package com.atlassian.bitbucket.analyzer.internal.log.util;

import com.atlassian.bitbucket.analyzer.internal.log.sample.AutoCloseableIterator;

import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

@SuppressWarnings("unchecked")
public class MergingAutoCloseableIterator<T> implements AutoCloseableIterator<T> {

    private final Comparator<T> comparator;
    private final List<AutoCloseableIterator<T>> delegates;
    private final Object[] nextValues;

    private T next;

    public MergingAutoCloseableIterator(List<AutoCloseableIterator<T>> delegates, Comparator<T> comparator) {
        this.comparator = comparator;
        this.delegates = delegates;
        this.nextValues = new Object[delegates.size()];
    }

    @Override
    public void close() {
        for (AutoCloseableIterator<T> delegate : delegates) {
            delegate.close();
        }
    }

    @Override
    public boolean hasNext() {
        if (next == null) {
            // next hasn't been initialized yet or all iterators are depleted
            for (int i = 0; i < nextValues.length; ++i) {
                if (nextValues[i] == null) {
                    advanceDelegate(i);
                }
                T nextI = (T) nextValues[i];
                if (nextI != null && (next == null || comparator.compare(nextI, next) < 0)) {
                    next = nextI;
                }
            }
        }

        return next != null;
    }

    @Override
    public T next() {
        if (hasNext()) {
            // move each of the iterators that is at the ref that we just returned one forward to prevent
            // returning the same ref multiple times _and_ determine the next element to return
            T returnedElem = next;
            next = null;

            for (int i = 0; i < nextValues.length; ++i) {
                T nextI = (T) nextValues[i];
                if (nextI != null && comparator.compare(nextI, returnedElem) == 0) {
                    nextI = advanceDelegate(i);
                }
                if (next == null || (nextI != null && comparator.compare(nextI, next) < 0)) {
                    next = nextI;
                }
            }
            return returnedElem;
        }
        throw new NoSuchElementException("iterator is depleted");
    }

    private T advanceDelegate(int index) {
        Iterator<T> iterator = delegates.get(index);
        nextValues[index] = iterator.hasNext() ? iterator.next() : null;
        return (T) nextValues[index];
    }
}