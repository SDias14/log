package com.atlassian.bitbucket.analyzer.internal.log.callback;

import com.atlassian.bitbucket.analyzer.internal.log.ParserConfiguration;
import com.atlassian.bitbucket.analyzer.internal.log.sample.Sample;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * Callback that calculates number of calls, min, max and average duration of the calls for a given sampling interval.
 */
public class IntervalStatsCallback<S extends Sample<S>> implements SampleCallback<S> {

    public static final String SEP = "\t";

    private final ParserConfiguration configuration;
    private final List<IntervalTracker<S>> trackers = new ArrayList<>();

    private long windowEnd = -1L;

    public IntervalStatsCallback(ParserConfiguration configuration) throws IOException {
        this.configuration = configuration;
    }

    public IntervalStatsCallback<S> track(Collection<IntervalTracker<S>> trackers) {
        this.trackers.addAll(trackers);
        return this;
    }

    @SafeVarargs
    public final IntervalStatsCallback<S> track(IntervalTracker<S>... trackers) {
        return track(Arrays.asList(trackers));
    }


    @Override
    public void start() throws IOException {
        for (IntervalTracker tracker : trackers) {
            tracker.start();
        }
    }

    @Override
    public void onSample(S sample) throws IOException {
        long intervalMillis = TimeUnit.SECONDS.toMillis(configuration.getSampleIntervalSec());
        if (windowEnd == -1L) {
            for (IntervalTracker<S> tracker : trackers) {
                tracker.onStart(sample.getTimestamp(), intervalMillis);
            }
            windowEnd = sample.getTimestamp() + intervalMillis;
        }

        for (IntervalTracker<S> tracker : trackers) {
            tracker.onSample(sample);
        }

        if (sample.getTimestamp() > windowEnd) {
            Date intervalStartDate = new Date(windowEnd - intervalMillis);
            Date intervalEndDate = new Date(windowEnd);
            for (IntervalTracker tracker : trackers) {
                tracker.write(intervalStartDate, intervalEndDate);
            }

            windowEnd += intervalMillis;
        }
    }

    @Override
    public void finish() throws IOException {
        for (IntervalTracker<S> tracker : trackers) {
            tracker.finish();
        }
    }
}
