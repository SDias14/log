package com.atlassian.bitbucket.analyzer.internal.log.callback;

import com.atlassian.bitbucket.analyzer.internal.log.access.ConcurrencySample;
import com.atlassian.bitbucket.analyzer.internal.log.sample.RequestSample;

import java.io.*;
import java.util.*;
import java.util.function.Predicate;

public class ConcurrencyIntervalTracker<S extends RequestSample<S>> implements IntervalTracker<S> {

    private final Predicate<S> includePredicate;
    private final DataOutputStreamProvider outputStreamProvider;

    private S lastSample;
    private List<Long> orderedEnds = new LinkedList<>();
    private long lastTimestamp = -1L;
    private int concurrency = 0;
    private int minConcurrency = 0;
    private int maxConcurrency = 0;
    private long sumConcurrency = 0L;

    public ConcurrencyIntervalTracker(Predicate<S> includePredicate,
                                      DataOutputStreamProvider outputProvider) {
        this.includePredicate = includePredicate;
        this.outputStreamProvider = outputProvider;
    }

    @Override
    public void finish() {
        outputStreamProvider.close();
    }

    @Override
    public void start() throws IOException {
    }

    @Override
    public void onSample(S sample) {
        if (lastSample != null && sample.getTimestamp() < lastSample.getTimestamp()) {
            long diff = (lastSample.getTimestamp() - sample.getTimestamp());
            if (diff > 100L) {
                System.out.println("Got an out-of-order sample: " + diff
                        + "\n\t this sample = " + sample + "\n\tprev sample = " + lastSample);
            }
        }
        lastSample = sample;

        if (includePredicate.test(sample)) {
            // process concurrency up to the sample start
            updateConcurrencyUpTo(sample.getTimestamp());

            maxConcurrency = Math.max(maxConcurrency, ++concurrency);

            // schedule the decrease in concurrency for the operation
            long sampleEnd = Long.MAX_VALUE;
            if (sample.getDuration() != null) {
                sampleEnd = sample.getTimestamp() + sample.getDuration();
            }
            int addIndexEnd = Collections.binarySearch(orderedEnds, sampleEnd);
            if (addIndexEnd < 0) {
                addIndexEnd = ~addIndexEnd;
            }
            orderedEnds.add(addIndexEnd, sampleEnd);
        }
    }

    @Override
    public void onStart(long firstIntervalStart, long intervalSize) {
        lastTimestamp = firstIntervalStart;
    }

    @Override
    public void write(Date intervalStart, Date intervalEnd) throws IOException {
        updateConcurrencyUpTo(intervalEnd.getTime());
        double interval = intervalEnd.getTime() - intervalStart.getTime();

        new ConcurrencySample(intervalStart.getTime(), minConcurrency, sumConcurrency / interval, maxConcurrency)
                .writeTo(outputStreamProvider.get(intervalStart));

        minConcurrency = maxConcurrency = concurrency;
        sumConcurrency = 0L;
    }

    private void updateConcurrencyUpTo(long timestamp) {
        Iterator<Long> endsIt = orderedEnds.iterator();
        while (endsIt.hasNext()) {
            Long end = endsIt.next();
            if (end >= timestamp) {
                break;
            }

            endsIt.remove();
            if (lastTimestamp > 0) {
                if (end >= lastTimestamp) {
                    sumConcurrency += concurrency * (end - lastTimestamp);
                } else {
                    System.out.println("End < timestamp; difference = " + (end - timestamp));
                }
            }
            lastTimestamp = end;
            minConcurrency = Math.min(minConcurrency, --concurrency);
        }

        if (lastTimestamp < timestamp) {
            sumConcurrency += concurrency * (timestamp - lastTimestamp);
            lastTimestamp = timestamp;
        }
    }
}
