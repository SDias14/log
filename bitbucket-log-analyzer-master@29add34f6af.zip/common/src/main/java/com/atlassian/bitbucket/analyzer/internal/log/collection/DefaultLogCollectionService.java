package com.atlassian.bitbucket.analyzer.internal.log.collection;

import com.atlassian.bitbucket.analyzer.internal.log.AnalyzerConfig;

import javax.annotation.Nonnull;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.util.Optional.empty;
import static java.util.Optional.of;

public class DefaultLogCollectionService implements LogCollectionService {

    private final AnalyzerConfig config;

    public DefaultLogCollectionService(AnalyzerConfig config) {
        this.config = config;
    }

    @Nonnull
    @Override
    public LogCollection create(@Nonnull String name) {
        File dataDir = config.getDataDirectory();
        if (dataDir == null || !dataDir.isDirectory()) {
            throw new IllegalStateException("Data directory in invalid");
        }

        String sanitizedName = name.trim();
        File collectionDir = new File(dataDir, sanitizedName);
        if (collectionDir.exists() && !collectionDir.isDirectory()) {
            throw new IllegalArgumentException("A file exists at the specified location - " + collectionDir.getAbsolutePath());
        }

        try {
            Files.createDirectories(collectionDir.toPath());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return internalGet(collectionDir.toPath());
    }

    @Nonnull
    @Override
    public Optional<LogCollection> get(@Nonnull String name) {
        File dataDir = config.getDataDirectory();
        if (dataDir == null || !dataDir.isDirectory()) {
            return empty();
        }

        String sanitizedName = name.trim();
        File collectionDir = new File(dataDir, sanitizedName);
        if (collectionDir.exists() && collectionDir.isDirectory()) {
            return of(internalGet(collectionDir.toPath()));
        }
        return empty();
    }

    @Nonnull
    @Override
    public List<ImportDetails> getImports(@Nonnull LogCollection logCollection) throws IOException {
        List<Path> importPaths = Files.list(logCollection.getPath())
                .filter(path -> {
                    String filename = path.getFileName().toString();
                    return filename.startsWith("import-") && filename.endsWith(".properties");
                }).collect(Collectors.toList());
        List<ImportDetails> imports = new ArrayList<>();
        for (Path path : importPaths) {
            imports.add(ImportDetails.load(path));
        }
        return imports;
    }

    @Nonnull
    @Override
    public Stream<LogCollection> stream() {
        File dataDir = config.getDataDirectory();
        if (dataDir == null || !dataDir.isDirectory()) {
            return Collections.<LogCollection>emptyList().stream();
        }

        try {
            return Files.list(dataDir.toPath())
                    .filter(path -> path.toFile().isDirectory())
                    .map(this::internalGet);
        } catch (IOException e) {
            return Collections.<LogCollection>emptyList().stream();
        }
    }

    private LogCollection internalGet(Path path) {
        return new LogCollection(path.getFileName().toString(), path, null, null);
    }
}
