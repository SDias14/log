package com.atlassian.bitbucket.analyzer.internal.log.collection;

import com.atlassian.bitbucket.analyzer.internal.log.Operation;
import com.atlassian.bitbucket.analyzer.internal.log.store.DataStore;

import javax.annotation.Nonnull;
import java.io.File;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class ImportRequest {
    private final boolean cacheRatio;
    private final boolean concurrency;
    private final DataStore dataStore;
    private final boolean generalStatistics;
    private final Path logDirectory;
    private final List<Operation> operations;
    private final long sampleIntervalSec;

    private ImportRequest(Builder builder) {
        cacheRatio = builder.cacheRatio;
        concurrency = builder.concurrency;
        dataStore = builder.dataStore;
        generalStatistics = builder.generalStatistics;
        logDirectory = builder.logDirectory;
        operations = new ArrayList<>(builder.operations);
        sampleIntervalSec = builder.sampleIntervalSec;
    }

    public DataStore getDataStore() {
        return dataStore;
    }

    public boolean isCacheRatio() {
        return cacheRatio;
    }

    public boolean isConcurrency() {
        return concurrency;
    }

    public boolean isGeneralStatistics() {
        return generalStatistics;
    }

    public Path getLogDirectory() {
        return logDirectory;
    }

    public List<Operation> getOperations() {
        return Collections.unmodifiableList(operations);
    }

    public long getSampleInterval() {
        return sampleIntervalSec;
    }

    public static class Builder {
        private boolean cacheRatio;
        private boolean concurrency;
        private DataStore dataStore;
        private boolean generalStatistics;
        private Path logDirectory;
        private List<Operation> operations;
        private long sampleIntervalSec;

        public Builder() {
            cacheRatio = false;
            concurrency = false;
            generalStatistics = true;
            operations = new ArrayList<>();
            sampleIntervalSec = TimeUnit.MINUTES.toSeconds(1);
        }

        @Nonnull
        public ImportRequest build() {
            return new ImportRequest(this);
        }

        @Nonnull
        public Builder cacheRatios(boolean value) {
            cacheRatio = value;
            return this;
        }

        @Nonnull
        public Builder concurrency(boolean value) {
            concurrency = value;
            return this;
        }

        @Nonnull
        public Builder dataStore(DataStore value) {
            dataStore = value;
            return this;
        }

        @Nonnull
        public Builder logDirectory(Path value) {
            logDirectory = value;
            return this;
        }

        @Nonnull
        public Builder operation(@Nonnull Operation value) {
            operations.add(value);
            return this;
        }

        @Nonnull
        public Builder operations(@Nonnull Collection<Operation> values) {
            operations.addAll(values);
            return this;
        }

        @Nonnull
        public Builder requestStatistics(boolean value) {
            generalStatistics = value;
            return this;
        }

        @Nonnull
        public Builder sampleInterval(long value, TimeUnit timeUnit) {
            sampleIntervalSec = timeUnit.toSeconds(value);
            return this;
        }
    }
}
