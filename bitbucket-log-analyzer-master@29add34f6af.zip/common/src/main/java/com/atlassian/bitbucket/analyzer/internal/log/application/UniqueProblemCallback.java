package com.atlassian.bitbucket.analyzer.internal.log.application;

import com.atlassian.bitbucket.analyzer.internal.log.callback.DataOutputStreamProvider;
import com.atlassian.bitbucket.analyzer.internal.log.callback.SampleCallback;

import java.io.DataOutputStream;
import java.io.IOException;
import java.util.*;
import java.util.function.Predicate;

public class UniqueProblemCallback implements SampleCallback<StandardLogSample> {

    private final DataOutputStreamProvider outputProvider;
    private final Predicate<StandardLogSample> predicate;
    private final Map<String, Problem> sampleMap;

    public UniqueProblemCallback(Predicate<StandardLogSample> includePredicate, DataOutputStreamProvider outputProvider) {
        this.outputProvider = outputProvider;
        this.predicate = includePredicate;

        this.sampleMap = new HashMap<>();
        outputProvider.onBeforeClose(this::flush);
    }

    @Override
    public void onSample(StandardLogSample sample) throws IOException {
        if (!predicate.test(sample)) {
            // ignore sample, just skip
            return;
        }

        String hash = sample.calculateHash();
        Problem s = sampleMap.get(hash);
        if (s == null) {
            sampleMap.put(hash, new Problem(sample));
        } else {
            s.add(sample);
        }
        outputProvider.get(sample.getDate());
    }

    @Override
    public void finish() throws IOException {
        outputProvider.close();
    }

    private void flush(DataOutputStream out) {
        List<Problem> problems = new ArrayList<>(sampleMap.values());
        Collections.sort(problems);
        for (Problem p : problems) {
            try {
                p.writeTo(out);
            } catch (IOException e) {
                System.err.println(e.getMessage());
            }
        }
        sampleMap.clear();
    }
}
