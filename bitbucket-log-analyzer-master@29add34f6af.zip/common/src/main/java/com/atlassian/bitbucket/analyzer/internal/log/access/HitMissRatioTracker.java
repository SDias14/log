package com.atlassian.bitbucket.analyzer.internal.log.access;

import com.atlassian.bitbucket.analyzer.internal.log.callback.DataOutputStreamProvider;
import com.atlassian.bitbucket.analyzer.internal.log.callback.IntervalTracker;

import java.io.*;
import java.util.Date;
import java.util.function.Predicate;

public class HitMissRatioTracker implements IntervalTracker<AccessLogSample> {

    private final Predicate<AccessLogSample> includePredicate;
    private final DataOutputStreamProvider outputProvider;

    private int hits;
    private int misses;
    private int other;

    public HitMissRatioTracker(Predicate<AccessLogSample> includePredicate, DataOutputStreamProvider outputProvider) {
        this.includePredicate = includePredicate;
        this.outputProvider = outputProvider;
    }

    @Override
    public void start() throws IOException {
    }

    @Override
    public void finish() throws IOException {
        outputProvider.close();
    }

    @Override
    public void onSample(AccessLogSample sample) {
        if (!includePredicate.test(sample)) {
            // does not match the requested operation - skip sample
            return;
        }

        if (sample.isCacheHit()) {
            ++hits;
        } else if (sample.isCacheMiss()) {
            ++misses;
        } else {
            ++other;
        }
    }

    @Override
    public void onStart(long firstIntervalStart, long intervalSize) {
    }

    @Override
    public void write(Date intervalStart, Date intervalEnd) throws IOException {
        new CacheRatioSample(intervalStart.getTime(), hits, misses, other)
                .writeTo(outputProvider.get(intervalStart));
        hits = misses = other = 0;
    }
}
