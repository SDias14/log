package com.atlassian.bitbucket.analyzer.internal.log.application;

/**
 * Log level from the application log
 */
public enum Level {
    TRACE(0),
    DEBUG(20),
    INFO(40),
    WARN(60),
    ERROR(80),
    FATAL(100);

    public final int severity;

    Level(int severity) {
        this.severity = severity;
    }
}
