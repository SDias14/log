package com.atlassian.bitbucket.analyzer.internal.log.sample;

/**
 * Base interface of all supported log samples
 */
public interface Sample<S extends Sample<S>> extends Comparable<S> {
    long getTimestamp();
}
