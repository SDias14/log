package com.atlassian.bitbucket.analyzer.internal.log.application;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static java.util.Optional.empty;
import static java.util.Optional.of;

public class KnownIssuesHasher {
    private static final List<String> KNOWN_PREFIXES = new ArrayList<>();
    private static final List<String> KNOWN_SUBSTRINGS = new ArrayList<>();

    static {
        KNOWN_PREFIXES.add("Indexing - Failed for repository ");
        KNOWN_PREFIXES.add("Indexing - Failed for project ");
        KNOWN_PREFIXES.add("Invalid cookie header: \"Set-Cookie: AWSALB");
        KNOWN_PREFIXES.add("Invalid cookie header: \"Set-Cookie: did");
        KNOWN_PREFIXES.add("Invalid cookie header: \"Set-Cookie: auth0");
        KNOWN_PREFIXES.add("XSRF failure not being enforced for request");

        KNOWN_SUBSTRINGS.add("is not functional during authentication of ");
        KNOWN_SUBSTRINGS.add("Asking if operation execution has been started");
        KNOWN_SUBSTRINGS.add("error: Response object did not contain key 'found'");
        KNOWN_SUBSTRINGS.add("Retrying invocation");
        KNOWN_SUBSTRINGS.add("is already in the current diff");
        KNOWN_SUBSTRINGS.add("Comments have already been drifted");
        KNOWN_SUBSTRINGS.add("coverage entries were deleted for commit");
        KNOWN_SUBSTRINGS.add("cannot be merged automatically due to conflicts in");
    }

    public static Optional<String> getHash(String message) {
        for (String prefix : KNOWN_PREFIXES) {
            if (message.startsWith(prefix)) {
                return of(prefix);
            }
        }
        for (String substring : KNOWN_SUBSTRINGS) {
            if (message.contains(substring)) {
                return of(substring);
            }
        }

        return empty();
    }
}
