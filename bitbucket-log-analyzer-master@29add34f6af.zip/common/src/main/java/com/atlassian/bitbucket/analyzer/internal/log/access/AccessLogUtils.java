package com.atlassian.bitbucket.analyzer.internal.log.access;

import com.atlassian.bitbucket.analyzer.internal.log.Operation;
import com.atlassian.bitbucket.analyzer.internal.log.ParserConfiguration;
import com.atlassian.bitbucket.analyzer.internal.log.callback.ConcurrencyIntervalTracker;
import com.atlassian.bitbucket.analyzer.internal.log.callback.DataOutputStreamProvider;
import com.atlassian.bitbucket.analyzer.internal.log.callback.RequestStatisticsTracker;
import com.atlassian.bitbucket.analyzer.internal.log.callback.IntervalTracker;
import com.atlassian.bitbucket.analyzer.internal.log.store.DataType;

import java.util.function.Predicate;

public class AccessLogUtils {

    public static IntervalTracker<AccessLogSample> cacheRatioTracker(Operation operation, ParserConfiguration configuration) {
        return new HitMissRatioTracker(AccessLogUtils.isOperation(operation),
                new DataOutputStreamProvider(configuration, DataType.CACHE_RATIO, operation));
    }

    public static IntervalTracker<AccessLogSample> concurrencyTracker(Operation operation, ParserConfiguration configuration) {
        return new ConcurrencyIntervalTracker<>(AccessLogUtils.isOperation(operation),
                new DataOutputStreamProvider(configuration, DataType.CONCURRENCY, operation));
    }

    public static IntervalTracker<AccessLogSample> requestStatisticsTracker(Operation operation, ParserConfiguration configuration) {
        return new RequestStatisticsTracker<>(AccessLogUtils.isOperation(operation),
                new DataOutputStreamProvider(configuration, DataType.REQUEST_STATISTICS, operation));
    }

    public static Predicate<AccessLogSample> isOperation(Operation operation) {
        return sample -> sample.getOperations().contains(operation);
    }
}
