package com.atlassian.bitbucket.analyzer.internal.log;

import com.atlassian.bitbucket.analyzer.internal.log.access.AccessLogParser;
import com.atlassian.bitbucket.analyzer.internal.log.access.AccessLogSample;
import com.atlassian.bitbucket.analyzer.internal.log.access.WindowingAccessLogSampleCallback;
import com.atlassian.bitbucket.analyzer.internal.log.callback.IntervalStatsCallback;
import com.atlassian.bitbucket.analyzer.internal.log.store.DataStore;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static com.atlassian.bitbucket.analyzer.internal.log.Operation.*;
import static com.atlassian.bitbucket.analyzer.internal.log.access.AccessLogUtils.cacheRatioTracker;
import static com.atlassian.bitbucket.analyzer.internal.log.access.AccessLogUtils.concurrencyTracker;
import static com.atlassian.bitbucket.analyzer.internal.log.access.AccessLogUtils.requestStatisticsTracker;

public class Main {
    public static final String FROM_DATE = "--from";
    public static final String HELP = "--help";
    public static final String LOG_DIR = "--log-dir";
    public static final String INTERVAL = "--interval";
    public static final String OUTPUT_DIR = "--output-dir";
    public static final String REPO = "--repo";
    public static final String TO_DATE = "--to";

    public static void main(String[] argv) throws IOException {
        Set<String> repos = new HashSet<>();

        Date from = null;
        Date to = null;
        File logFileDir = null;
        File outputDir = null;
        long intervalMin = -1L;
        boolean usage = false;
        for (int i = 0; i < argv.length; ++i) {
            switch (argv[i]) {
                case HELP:
                    System.out.println(usage());
                    return;
                case FROM_DATE:
                    try {
                        from = parseDate(argv[++i]);
                    } catch (ParseException e) {
                        System.err.println("Could not parse date '" + argv[i] + "'");
                    }
                    break;
                case TO_DATE:
                    try {
                        to = parseDate(argv[++i]);
                    } catch (ParseException e) {
                        System.err.println("Could not parse date '" + argv[i] + "'");
                    }
                    break;
                case LOG_DIR:
                    logFileDir = new File(argv[++i]);
                    break;
                case OUTPUT_DIR:
                    outputDir = new File(argv[++i]);
                    break;
                case INTERVAL:
                    intervalMin = Long.valueOf(argv[++i]);
                    break;
                case REPO:
                    String[] parts = argv[++i].split(",");
                    for (String part : parts) {
                        repos.add(part.trim().toLowerCase());
                    }
                    break;
                default:
                    System.err.println("Unrecognized option '" + argv[i] + "'\n");
                    usage = true;
            }
        }

        if (usage) {
            System.err.println(usage());
            return;
        }

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
            logFileDir = promptForDirectory(reader, logFileDir, "Log file directory: ", false);
            outputDir = promptForDirectory(reader, outputDir, "Output directory: ", true);

            System.out.println("Configuration:" +
                    "\n\tLog file directory: " + logFileDir.getAbsolutePath() +
                    "\n\tOutput directory: " + outputDir.getAbsolutePath() +
                    "\n\tSample interval (minutes): " + (intervalMin == -1 ? "15 (default)" : intervalMin) + "\n");

            boolean run = false;
            boolean concurrency = true;
            boolean requestPerMinute = true;
            boolean cacheRatio = false;
            List<Operation> operations = new ArrayList<>();
            operations.addAll(Arrays.asList(ALL, HOSTING, HOSTING_FETCH, HOSTING_CLONE, HOSTING_PUSH, HOSTING_REFS,
                    HTTP_HOSTING, HTTP_HOSTING_CLONE, HTTP_HOSTING_FETCH, HTTP_HOSTING_NEGOTIATION, HTTP_HOSTING_PUSH,
                    HTTP_HOSTING_REFS, SSH_HOSTING, SSH_HOSTING_ARCHIVE, SSH_HOSTING_CLONE, SSH_HOSTING_FETCH,
                    SSH_HOSTING_NEGOTIATION, SSH_HOSTING_PUSH, SSH_HOSTING_REFS,
                    REST, REST_PR_MERGE, REST_PULL_REQUEST, REST_INBOX, REST_JIRA, UI, UI_PULL_REQUEST_ACTIVITY,
                    UI_PULL_REQUEST_COMMITS, UI_PULL_REQUEST_DIFF, UI_PULL_REQUEST_LIST, UI_PULL_REQUEST_COMMITS,
                    STATUS, HTTP, REST_DELETE, REST_DELETE_REPOSITORY, REST_DELETE_PROJECT, SSH));
            while (!run) {
                System.out.println("Configured categories: \n" +
                        padBlock(operations.stream().map(Operation::toString).collect(Collectors.joining(", ")), "\t", 80) +
                        "\n\nGraphs to generate" +
                        "\n\t[" + (cacheRatio ? "x" : " ") + "] cache hit/miss ratio for hosting operations" +
                        "\n\t[" + (requestPerMinute ? "x" : " ") + "] requests per minute" +
                        "\n\t[" + (concurrency ? "x" : " ") + "] concurrency");

                System.out.println(
                        "\n\t0 - " + (cacheRatio ? "disable" : "enable") + " cache hits/miss" +
                        "\n\t1 - " + (requestPerMinute ? "disable" : "enable") + " requests per minute" +
                        "\n\t2 - " + (concurrency ? "disable" : "enable") + " concurrency" +
                        "\n\t3 - generate graphs" +
                        "\n\t9 - cancel"
                );
                int action = promptForInt(reader, "What next: ");
                switch (action) {
                    case 0:
                        cacheRatio = !cacheRatio;
                        break;
                    case 1:
                        requestPerMinute = !requestPerMinute;
                        break;
                    case 2:
                        concurrency = !concurrency;
                        break;
                    case 3:
                        run = true;
                        break;
                    case 9:
                        return;
                   default:
                        System.err.println("Invalid option");
                }
            }

            DataStore store = new DataStore(outputDir.toPath());

            ParserConfiguration.Builder configurationBuilder = new ParserConfiguration.Builder()
                    .logFileDirectory(logFileDir.toPath())
                    .dataStore(store)
                    .period(from, to);
            if (intervalMin > 0) {
                configurationBuilder.sampleInterval(intervalMin, TimeUnit.MINUTES);
            }
            ParserConfiguration configuration = configurationBuilder.build();

            IntervalStatsCallback<AccessLogSample> intervalCallback = new IntervalStatsCallback<>(configuration);
            if (requestPerMinute) {
                operations.stream()
                        .map(op -> requestStatisticsTracker(op, configuration))
                        .forEach(intervalCallback::track);
            }
            if (concurrency) {
                operations.stream()
                        .map(op -> concurrencyTracker(op, configuration))
                        .forEach(intervalCallback::track);
            }
            if (cacheRatio) {
                operations.stream()
                        .filter(op -> op.inInCategory(HOSTING))
                        .map(op -> cacheRatioTracker(op, configuration))
                        .forEach(intervalCallback::track);
            }
            WindowingAccessLogSampleCallback callback = new WindowingAccessLogSampleCallback(intervalCallback);

            new AccessLogParser(configuration).parse(callback);
        }
    }

    private static String padBlock(String value, String padding, int width) {
        StringBuilder builder = new StringBuilder();
        while (value.length() > width) {
            int index = value.lastIndexOf(' ', width);
            builder.append(padding).append(value.substring(0, index)).append('\n');
            value = value.substring(index + 1);
        }
        builder.append(padding).append(value);
        return builder.toString();
    }

    private static Date parseDate(String value) throws ParseException {
        DateFormat formats[] = new DateFormat[]{
                new SimpleDateFormat("y-M-d H:m:s"), new SimpleDateFormat("y-M-d H:m"), new SimpleDateFormat("y-M-d"),
                new SimpleDateFormat("y/M/d H:m:s"), new SimpleDateFormat("y/M/d H:m"), new SimpleDateFormat("y/M/d")};

        ParseException lastException = null;
        for (DateFormat format : formats) {
            try {
                return format.parse(value);
            } catch (ParseException e) {
                lastException = e;
            }
        }
        throw lastException;
    }

    private static File promptForDirectory(BufferedReader reader, File dir, String prompt, boolean create) throws IOException {
        File result = dir;
        while (true) {
            if (result != null) {
                if (result.isFile()) {
                    System.err.println(result.getAbsolutePath() + " is not a directory");
                } else if (!result.exists()) {
                    if (create) {
                        try {
                            Files.createDirectories(result.toPath());
                        } catch (IOException e) {
                            System.err.println("Could not create directory " + result.getAbsolutePath() + " : " + e.getMessage());
                        }
                    } else {
                        System.err.println(result.getAbsolutePath() + " not found");
                    }
                }
                if (result.isDirectory()) {
                    return result;
                }
            }
            System.out.print(prompt);
            String path = reader.readLine();
            if (path != null) {
                result = new File(path);
            }
        }
    }

    private static int promptForInt(BufferedReader reader, String prompt) throws IOException {
        int result = -1;
        while (result == -1) {
            System.out.print(prompt);
            String line = reader.readLine();
            try {
                result = Integer.parseInt(line);
            } catch (NumberFormatException e) {
                // ignore and just reprint prompt
            }
        }
        return result;
    }

    private static String usage() {
        return "Usage:" +
                "\n\t" + LOG_DIR + " - the directory containing the log files" +
                "\n\t" + OUTPUT_DIR + " - the directory where the graphs should be stored" +
                "\n\t" + FROM_DATE + " - from date" +
                "\n\t" + TO_DATE + " - to date" +
                "\n\t" + INTERVAL + " - interval in minutes for grouping statistics such as averaged, max, min, etc";
    }
}

