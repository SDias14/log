package com.atlassian.bitbucket.analyzer.internal.log;

import java.util.*;

public class ConcurrencyTracker {

    public int count;
    public int maxDuration;
    public long maxConcurrency = 0L;
    public int maxQueueTime;
    public int concurrency = 0;
    private long startTimeMillis = 0L;
    private long millisWithAnyOperation = 0L;
    private long millisTimesConcurrentOperations = 0L;
    private long processedUpTo = 0L;
    private List<Long> orderedEnds = new LinkedList<>();
    private Long lastTime;
    private List<ConcurrencySegment> segments = new LinkedList<>();

    public void processSample(Date startTime, int duration, int queueTime) {
        maxDuration = Math.max(maxDuration, duration);
        maxQueueTime = Math.max(maxQueueTime, queueTime);
        ++count;

        ListIterator<Long> it = orderedEnds.listIterator();
        Long sampleStart = startTime.getTime();
        Long sampleEnd = startTime.getTime() + duration;
        if (startTimeMillis == 0L) {
            startTimeMillis = sampleStart;
        }
        long rangeStart = processedUpTo;
        while (it.hasNext()) {
            Long rangeEnd = it.next();
            if (rangeEnd <= sampleStart) {
                it.remove();
                millisTimesConcurrentOperations += concurrency * (rangeEnd - rangeStart);

                // the next range begins where we left of
                rangeStart = rangeEnd;
                addSegment(concurrency--, rangeEnd);
            } else {
                break;
            }
        }

        addSegment(concurrency++, sampleStart);
        maxConcurrency = Math.max(concurrency, maxConcurrency);
        processedUpTo = sampleStart;

        int addIndexEnd = Collections.binarySearch(orderedEnds, sampleEnd);
        if (addIndexEnd < 0) addIndexEnd = ~addIndexEnd;
        orderedEnds.add(addIndexEnd, sampleEnd);
    }

    private void addSegment(int concurrency, long time) {
        if (concurrency != 0) {
            segments.add(new ConcurrencySegment(concurrency, time - lastTime));
        }
        lastTime = time;
    }

    public void finish() {
        ListIterator<Long> it = orderedEnds.listIterator();
        while (it.hasNext()) {
            Long decrement = it.next();
            it.remove();

            millisWithAnyOperation += (decrement - processedUpTo);
            millisTimesConcurrentOperations += concurrency * (decrement - processedUpTo);

            processedUpTo = decrement;
            addSegment(concurrency--, decrement);
        }
    }

    public Long getMaxConcurrency() {
        return maxConcurrency;
    }

    public int getMaxQueueTime() {
        return maxQueueTime;
    }

    public String toString() {
        double averageConcurrency = (1.0d * millisTimesConcurrentOperations) / millisWithAnyOperation;
        long totalTime = (processedUpTo - startTimeMillis);

        String ret =
                "\n\t#samples: " + count + "\n\tmaxDuration: " + maxDuration + "\n\tmaxQueueTime: " +
                        maxQueueTime + "\n\tmaxConcurrency: " + maxConcurrency +
                        "\n\tmeanConcurrency: " + (averageConcurrency) +
                        "\n\ttotalTimeWithOperations: " + millisWithAnyOperation +
                        "\n\ttotalTimeNoOperations: " + (totalTime - millisWithAnyOperation) +
                        "\n\ttotalTime: " + totalTime + "\n";


        StringBuilder str = new StringBuilder(ret);
        for (ConcurrencySegment segment : segments) {
            str.append(segment).append("\n");
        }
        return str.toString();
    }

    private static class ConcurrencySegment {
        private final int concurrency;
        private final long durationMillis;

        public ConcurrencySegment(int concurrency, long durationMillis) {
            this.concurrency = concurrency;
            this.durationMillis = durationMillis;
        }

        public String toString() {
            return concurrency + "\t" + durationMillis;
        }
    }
}
