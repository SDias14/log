package com.atlassian.bitbucket.analyzer.internal.log.sample;

import java.util.Iterator;

public interface AutoCloseableIterator<S> extends Iterator<S>, AutoCloseable {

    @Override
    void close();
}
