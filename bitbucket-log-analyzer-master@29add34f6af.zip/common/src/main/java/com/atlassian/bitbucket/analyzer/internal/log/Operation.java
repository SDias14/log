package com.atlassian.bitbucket.analyzer.internal.log;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public enum Operation {

    ALL("all", true),

    HOSTING("hosting operations", true, ALL),
    HOSTING_PROTOCOL_1("Git protocol 1", true, HOSTING),
    HOSTING_PROTOCOL_2("Git protocol 2", true, HOSTING),
    HOSTING_CLONE("clone", true, HOSTING),
    HOSTING_FETCH("fetch", true, HOSTING),
    HOSTING_NEGOTIATION("pack negotiation", true, HOSTING),
    HOSTING_PUSH("push", true, HOSTING),
    HOSTING_REFS("ref advertisement", true, HOSTING),
    HOSTING_UPLOAD_PACK_UNCLASSIFIED("upload-pack unclassified", true, HOSTING),

    HTTP_HOSTING("HTTP hosting", true, HOSTING),
    HTTP_HOSTING_PROTOCOL_1("HTTP Git protocol 1", true, HTTP_HOSTING),
    HTTP_HOSTING_PROTOCOL_2("HTTP Git protocol 2", true, HTTP_HOSTING),
    HTTP_HOSTING_CLONE("HTTP clone", HTTP_HOSTING),
    HTTP_HOSTING_FETCH("HTTP fetch", HTTP_HOSTING),
    HTTP_HOSTING_NEGOTIATION("HTTP pack negotiation", HTTP_HOSTING),
    HTTP_HOSTING_PUSH("HTTP push", HTTP_HOSTING),
    HTTP_HOSTING_REFS("HTTP ref advertisement", HTTP_HOSTING),
    HTTP_HOSTING_UPLOAD_PACK_UNCLASSIFIED("HTTP upload-pack unclassified", HTTP_HOSTING),

    HTTP("HTTP requests", true, ALL),
    SSH("SSH operations", true, ALL),

    SSH_HOSTING("SSH hosting", true, HOSTING),
    SSH_HOSTING_PROTOCOL_1("SSH Git protocol 1", true, SSH_HOSTING),
    SSH_HOSTING_PROTOCOL_2("SSH Git protocol 2", true, SSH_HOSTING),
    SSH_HOSTING_ARCHIVE("SSH archive", SSH_HOSTING),
    SSH_HOSTING_CLONE("SSH clone", SSH_HOSTING),
    SSH_HOSTING_FETCH("SSH fetch", SSH_HOSTING),
    SSH_HOSTING_NEGOTIATION("SSH pack negotiation", SSH_HOSTING),
    SSH_HOSTING_PUSH("SSH push", SSH_HOSTING),
    SSH_HOSTING_REFS("SSH ref advertisement", SSH_HOSTING),
    SSH_HOSTING_UPLOAD_PACK_UNCLASSIFIED("SSH upload-pack unclassified", SSH_HOSTING),

    SSH_CUSTOM("SSH custom command", ALL),

    PLUGIN("plugin", true, ALL),
    PLUGIN_MIRROR_PULL("mirror pull", PLUGIN),

    REST("REST", true, ALL),
    REST_ACTIVITY_STREAM("REST activity stream", REST),
    REST_ANALYTICS("REST analytics", REST),
    REST_API("REST bitbucket API", REST),
    REST_BUILD_STATUS("REST build status", REST),
    REST_CAPABILITIES("REST capabilities", REST),
    REST_CHAPERONE("REST chaperone", REST),
    REST_DASHBOARD_PRS("REST dashboard - pull requests", REST),
    REST_DASHBOARD_PR_SUGGESTIONS("REST dashboard - PR suggestions", REST),
    REST_INBOX("REST inbox", REST),
    REST_INSIGHTS("REST code insights", REST),
    REST_JIRA("REST JIRA issues", REST),
    REST_MENU("REST application switcher", REST),
    REST_MIRRORING("REST mirroring", REST),
    REST_RECENT_REPOS("REST recent repositories", REST),
    REST_SHORTCUTS("REST shortcuts", REST),
    REST_PULL_REQUEST("REST pull request", true, REST),
    REST_PR_ACTIVITIES("REST pull request activities", REST_PULL_REQUEST),
    REST_PR_LIST("REST pull request list", REST),
    REST_PR_MERGE("REST pull request merge", REST_PULL_REQUEST),
    REST_REMOTE_EVENT("REST remote event", REST),
    REST_UNCLASSIFIED("REST other", REST),

    REST_DELETE("Deletion of project or repository", REST),
    REST_DELETE_REPOSITORY("REST Deletion of repository", REST_DELETE),
    REST_DELETE_PROJECT("REST Deletion of project", REST_DELETE),

    STATUS("status", ALL),
    MAINTENANCE("maintenance", ALL),

    UI("UI", true, ALL),
    UI_LOGIN("UI login", UI),
    UI_PROJECT_LIST("UI project list", UI),
    UI_REPO_BROWSE("UI repository browse", UI),
    UI_REPO_LIST("UI repositories list", UI),
    UI_PULL_REQUEST_LIST("UI pull request_list", UI),
    UI_PULL_REQUEST_ACTIVITY("UI pull request activity", UI),
    UI_PULL_REQUEST_COMMITS("UI pull request commits", UI),
    UI_PULL_REQUEST_DIFF("UI pull request diff", UI),
    UI_PULL_REQUEST_OVERVIEW("UI pull request overview", UI),
    UI_STATIC_RESOURCES("UI static resources", UI),
    UI_UNCLASSIFIED("UI other", UI);

    private final String name;
    private final boolean category;
    private final Set<Operation> parentCategories;

    Operation(String name, Operation...parentCategories) {
        this(name, false, parentCategories);
    }

    Operation(String name, boolean category, Operation...parentCategories) {
        this.category = category;
        this.name = name;

        this.parentCategories = new HashSet<>();
        Arrays.stream(parentCategories)
                .forEach(parent -> {
                    this.parentCategories.addAll(parent.parentCategories);
                    this.parentCategories.add(parent);
                });
    }

    public static Operation fromId(String id) {
        for (Operation operation : values()) {
            if (operation.getId().equalsIgnoreCase(id)) {
                return operation;
            }
        }
        throw new IllegalArgumentException("No DataType exists with id " + id);
    }

    public boolean inInCategory(Operation operation) {
        return this == operation || parentCategories.contains(operation);
    }

    public boolean isCategory() {
        return category;
    }

    public String getId() {
        return name();
    }

    public String getName() {
        return name;
    }

    public String toFilename() {
        return toString().toLowerCase().replace(' ', '_');
    }

    @Override
    public String toString() {
        return name;
    }
}
