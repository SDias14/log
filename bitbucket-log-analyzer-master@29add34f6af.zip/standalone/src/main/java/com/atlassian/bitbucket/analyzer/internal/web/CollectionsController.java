package com.atlassian.bitbucket.analyzer.internal.web;

import com.atlassian.bitbucket.analyzer.internal.log.AnalyzerConfig;
import com.atlassian.bitbucket.analyzer.internal.log.Operation;
import com.atlassian.bitbucket.analyzer.internal.log.application.Problem;
import com.atlassian.bitbucket.analyzer.internal.log.collection.*;
import com.atlassian.bitbucket.analyzer.internal.log.sample.Sample;
import com.atlassian.bitbucket.analyzer.internal.log.store.DataStore;
import com.atlassian.bitbucket.analyzer.internal.log.store.DataType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Controller
public class CollectionsController {

    private static String[] DATE_PATTERNS = { "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm", "yyyy-MM-dd HH", "yyyy-MM-dd"};

    private final AnalyzerConfig config;
    private final DataService dataService;
    private final ImportService importService;
    private final LogCollectionService logCollectionService;

    @Autowired
    public CollectionsController(AnalyzerConfig config, DataService dataService, ImportService importService,
                                 LogCollectionService logCollectionService) {
        this.config = config;
        this.dataService = dataService;
        this.importService = importService;
        this.logCollectionService = logCollectionService;
    }

    @RequestMapping(path = "/collections", method = RequestMethod.POST)
    public String createCollection(Model model, @RequestParam(name = "name") String name) {
        logCollectionService.create(name);

        model.addAttribute("collections", logCollectionService.stream().collect(Collectors.toList()));

        return "collections";
    }

    @RequestMapping(path = "/collections/{name}")
    public String getCollection(@PathVariable("name") String collectionName, Model model) {
        Optional<LogCollection> collection = logCollectionService.get(collectionName);
        model.addAttribute("collection", collection.orElse(null));
        model.addAttribute("operations", Operation.values());

        return "collection";
    }

    @RequestMapping(path = "/")
    public String getCollectionsHome(Model model) {
        if (config.getDataDirectory() == null) {
            return "redirect:/config";
        }
        return getCollections(model);
    }

    @RequestMapping(path = "/collections")
    public String getCollections(Model model) {
        model.addAttribute("collections", logCollectionService.stream().collect(Collectors.toList()));

        return "collections";
    }

    @RequestMapping("/collections/{collection}/days")
    @ResponseBody
    public List<String> getCalendar(@PathVariable("collection") String collection) throws IOException {
        LogCollection logs = logCollectionService.get(collection).get();
        DataStore store = new DataStore(logs.getPath());
        return store.getAvailableDates(LocalDate.now().minus(1, ChronoUnit.YEARS)).stream()
                .map(date -> date.format(DateTimeFormatter.ISO_LOCAL_DATE))
                .collect(Collectors.toList());
    }

    @RequestMapping("/collections/{collection}/data/{dataTypeId}")
    @ResponseBody
    public List<Sample> getData(@PathVariable("collection") String collection,
                                @PathVariable("dataTypeId") String dataTypeId,
                                @RequestParam(value = "from", required = false) String from,
                                @RequestParam(value = "to", required = false) String to,
                                @RequestParam(value = "interval", required = false, defaultValue = "5") int interval) throws IOException {
        return getData(collection, null, dataTypeId, from, to, interval);
    }

    @RequestMapping("/collections/{collection}/data/{operationId}/{dataTypeId}")
    @ResponseBody
    public List<Sample> getData(@PathVariable("collection") String collection,
                                @PathVariable("operationId") String operationId,
                                @PathVariable("dataTypeId") String dataTypeId,
                                @RequestParam(value = "from", required = false) String from,
                                @RequestParam(value = "to", required = false) String to,
                                @RequestParam(value = "interval", required = false, defaultValue = "5") int interval) throws IOException {

        LogCollection logs = logCollectionService.get(collection).get();
        DataStore store = new DataStore(logs.getPath());
        Date fromDate = parseDate(from);
        Date toDate = parseDate(to);
        Operation operation = null;
        DataType type;
        try {
            type = DataType.fromId(dataTypeId);
            if (type != DataType.PROBLEMS) {
                operation = Operation.fromId(operationId);
            }
        } catch (IllegalArgumentException e) {
            throw new ResourceNotFoundException(e);
        }

        List<Sample> result = new ArrayList<>();
        switch (type) {
            case CACHE_RATIO:
                dataService.streamCacheRatio(store, fromDate, toDate, interval, operation, result::add);
                break;
            case CONCURRENCY:
                dataService.streamConcurrency(store, fromDate, toDate, interval, operation, result::add);
                break;
            case PROBLEMS:
                dataService.streamProblems(store, fromDate, toDate, new ProblemGrouper(), result::add);
            case REQUEST_STATISTICS:
                dataService.streamRequestStatistics(store, fromDate, toDate, interval, operation, result::add);
                break;
            default:
                return null;
        }
        return result;
    }

    @RequestMapping("/collections/{collection}/imports")
    @ResponseBody
    public List<ImportDetails> getImports(@PathVariable("collection") String collection) throws IOException {
        LogCollection logCollection = logCollectionService.create(collection);
        return logCollectionService.getImports(logCollection);
    }

    @RequestMapping(path = "/collections/{collection}/data", method = RequestMethod.POST)
    public String importData(@PathVariable("collection") String collection,
                             @RequestParam(name = "logDirectory") String logDirectory,
                             Model model) {

        LogCollection logCollection = logCollectionService.create(collection);

        long start = System.currentTimeMillis();
        try {
            ImportDetails result = importService.startImport(new ImportRequest.Builder()
                    .logDirectory(Paths.get(logDirectory))
                    .dataStore(new DataStore(logCollection.getPath()))
                    .concurrency(true)
                    .cacheRatios(true)
                    .requestStatistics(true)
                    .operations(Arrays.asList(Operation.values()))
                    .build()).get();

            // store the import results in the dataStore
            Path importDetailsPath = logCollection.getPath().resolve("import-" + result.getImportDate().getTime() + ".properties");
            result.save(importDetailsPath);

        } catch (InterruptedException e) {
            model.addAttribute("error", "Log import was interrupted");
        } catch (ExecutionException e) {
            model.addAttribute("error", "Log import failed: " + e.getCause().getMessage());
        } catch (IOException e) {
            model.addAttribute("error", "Log import failed: " + e.getMessage());
        }

        if (!model.containsAttribute("error")) {
            long timeSec = (System.currentTimeMillis() - start) / 1000;
            model.addAttribute("info", "Imported " + logDirectory + " into collection " + collection + " in " + timeSec + " seconds");
        }

        return "redirect:/collections/" + collection;
    }

    private Date parseDate(String parameter) {
        if (parameter == null) {
            return null;
        }

        for (String pattern : DATE_PATTERNS) {
            try {
                return new SimpleDateFormat(pattern).parse(parameter);
            } catch (ParseException e) {
                // ignore
            }
        }
        return null;
    }

    private static class ProblemGrouper implements Function<Problem, String> {

        private static final Map<Pattern, String> knownPatterns = new HashMap<>();
        static {
            knownPatterns.put(Pattern.compile("SONAR: Got 404 response"), "sonar-404");
            knownPatterns.put(Pattern.compile("SONAR: no component key found for file"), "sonar-no-component-key");
            knownPatterns.put(Pattern.compile("(Pull failed for repository)|(/plugins/servlet/mirror/pull/)"), "legacy-mirror");
            knownPatterns.put(Pattern.compile("Multiple build statuses for commitId"), "multiple-build-statuses");
        }

        @Override
        public String apply(Problem problem) {
            for (Map.Entry<Pattern, String> entry : knownPatterns.entrySet()) {
                Matcher matcher = entry.getKey().matcher(problem.getMessage());
                if (matcher.find()) {
                    return entry.getValue();
                }
            }
            return problem.calculateHash();
        }
    }


}
