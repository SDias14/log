package com.atlassian.bitbucket.analyzer.internal.web;

import com.atlassian.bitbucket.analyzer.internal.log.AnalyzerConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

@Controller
public class ConfigController {

    private final AnalyzerConfig config;

    @Autowired
    public ConfigController(AnalyzerConfig conf) {
        this.config = conf;
    }

    @RequestMapping(value = "/config", method = RequestMethod.GET)
    public String getConfig(Model model) {
        File dataDir = config.getDataDirectory();
        model.addAttribute("dataDirectory", dataDir == null ? null : dataDir.getAbsolutePath());

        return "config";
    }

    @RequestMapping(value = "/config", method = RequestMethod.POST)
    public String storeConfig(@RequestParam(name = "dataDirectory") String dataDirectory, Model model) {
        File dir = new File(dataDirectory);
        if (dir.exists() && !dir.isDirectory()) {
            model.addAttribute("error", dataDirectory + " is not a directory");
        } else if (!dir.exists()) {
            try {
                Files.createDirectories(dir.toPath());
            } catch (IOException e) {
                model.addAttribute("error", "Could not create directory " + dataDirectory);
            }
        }

        model.addAttribute("dataDirectory", dir.getAbsolutePath());
        if (dir.isDirectory()) {
            config.setDataDirectory(dir);
            model.addAttribute("info", "Configuration was updated");
            config.store();
        }
        return "config";
    }
}
