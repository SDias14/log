package com.atlassian.bitbucket.analyzer.internal.web;

import com.atlassian.bitbucket.analyzer.internal.log.AnalyzerConfig;
import com.atlassian.bitbucket.analyzer.internal.log.collection.*;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import javax.annotation.PreDestroy;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@SpringBootApplication
public class StandaloneMain {

    private ExecutorService executorService;

    @Bean
    public AnalyzerConfig config() {
        return AnalyzerConfig.load();
    }

    @Bean
    public DataService dataService() {
        return new DefaultDataService();
    }

    @Bean
    public ExecutorService executorService() {
        if (executorService == null) {
            executorService = Executors.newCachedThreadPool();
        }
        return executorService;
    }

    @Bean
    public ImportService importService() {
        return new DefaultImportService(executorService());
    }

    @Bean
    public LogCollectionService logCollectionService() {
        return new DefaultLogCollectionService(config());
    }

    @PreDestroy
    public void shutdown() {
        if (executorService != null) {
            executorService.shutdown();
            executorService = null;
        }
    }

    public static void main(String[] args) throws Exception {
        SpringApplication.run(StandaloneMain.class, args);
    }
}
