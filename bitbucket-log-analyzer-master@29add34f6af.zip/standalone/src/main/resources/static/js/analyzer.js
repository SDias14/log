var axisTimeFormat = d3.time.format.multi([
	[".%L", function(d) { return d.getMilliseconds(); }],
	[":%S", function(d) { return d.getSeconds(); }],
	["%H:%M", function(d) { return d.getMinutes(); }],
	["%H:%M", function(d) { return d.getHours(); }],
	["%a %d/%m", function(d) { return d.getDay() && d.getDate() != 1; }],
	["%d/%m", function(d) { return d.getDate() != 1; }],
	["%B", function(d) { return d.getMonth(); }],
	["%Y", function() { return true; }]
]);

var colors = d3.scale.category10();
var margin = {top: 40, right: 50, bottom: 30, left: 20};

String.prototype.capitalize = function() {
	return this.charAt(0).toUpperCase() + this.slice(1);
}

function label(svg, element, index, size, margin) {
    var group = svg.append("g").attr("class", "label").attr("transform", "translate(" + margin + "," + (margin + index * (margin + size)) + ")");
    group.append("svg:rect").attr("x", 0).attr("y", 0).attr("height", size).attr("width", size).attr("style", "fill: " + element.color);
    group.append("text").attr("x", margin+size).attr("y", margin / 2).text(element.label);
}

function labels(svg, elements) {
    var margin = 7, size = 10;
    for (i = 0; i < elements.length; ++i) {
		label(svg, elements[i], i, size, margin);
    }
}

function shortDate(d) {
	return pad(d.getDate()) + "-" + pad(d.getMonth() + 1) + " " +
		pad(d.getHours()) + ":" + pad(d.getMinutes()) + ":" + pad(d.getSeconds());
}

function pad(num) {
	return ("0" + num).slice(-2);
}

function updateDateRange(from, to) {
    var fromElem = $("#date-from");
    var toElem = $("#date-to");
    fromElem.val(from);
    fromElem.change();
    if (to === undefined) {
        var nextDay = new Date(from);
        nextDay.setDate(nextDay.getDate() + 1);
        to = nextDay.toISOString().substr(0, 10);
    }

    toElem.val(to);
    toElem.change();
    updateGraphs();
}

function createGraph(parentElem, label, width, height, styleClass) {
	var graph = {};
	graph.svg = d3.select(parentElem)
		.append("svg")
		.attr("class", styleClass)
		.attr("width", width + margin.left + margin.right)
		.attr("height", height + margin.top + margin.bottom);

	graph.svg.append("text")
		.attr("x", width / 2)
		.attr("y", 20)
		.style("text-anchor", "middle")
		.text(label);

	graph.scales = {
		x: d3.time.scale().range([0, width]),
		y: d3.scale.linear().range([height, 0])
	}

	graph.axes = {
		x: d3.svg.axis().scale(graph.scales.x).ticks(16).tickFormat(axisTimeFormat).orient("bottom"),
		y: d3.svg.axis().scale(graph.scales.y).ticks(10).orient("right")
	};

	graph.axes.addToGraph = function () {
		graph.svg.append("g")
			.attr("class", "x axis")
			.attr("transform", "translate(0," + height + ")")
			.call(graph.axes.x);

		graph.svg.append("g")
			.attr("class", "y axis")
			.attr("transform", "translate(" + width + ",0)")
			.call(graph.axes.y);
	};

	return graph;
}

function cacheRatioGraph(parentElem, dataUrl, label, width, height) {
	//Create SVG element
	d3.json(dataUrl, function(error, data) {
        if (data.length == 0) {
            parentElem.style.display = "none";
            return;
        }
        var graph = createGraph(parentElem, label, width, height, 'cache-ratio-graph');

        var lineX = function(d) { return graph.scales.x(d.timestamp); };
        var lines = [
            { label: 'misses', color: '#DE5C00', x: lineX, y: function(d) { return graph.scales.y(d.total > 0 ? (100.0 * (d.hits + d.misses)) / d.total : 0); }},
            { label: 'hits', color: '#007A21', x: lineX, y: function(d) { return graph.scales.y(d.total > 0 ? (100.0 * d.hits) / d.total : 0); }}];

        labels(graph.svg, lines);
        graph.svg = graph.svg.append("g")
            .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

        data.forEach(function(item) {
			item.timestamp = new Date(+ item.timestamp);
			item.total = item.hits + item.misses + item.other;
		});

		if (data.length != 0) {
			graph.scales.x.domain([data[0].timestamp, data[data.length - 1].timestamp]);
			graph.scales.y.domain([0, 100]);
		}

		graph.axes.addToGraph();

		var enter = graph.svg.selectAll(".cache-ratio")
			.data([data])
			.enter();

		var zero = function() { return graph.scales.y(0);};
		// other
		enter.append("svg:path")
			.attr("class", "area")
			.attr("style", "stroke: #B3B3B3; fill: #B3B3B3")
			.attr("d", d3.svg.area().interpolate('basis').x(lineX).y0(zero).y1(function() { return graph.scales.y(100)}));
		// misses
		enter.append("svg:path")
			.attr("class", "area")
			.attr("style", "stroke: " + lines[0].color + "; fill: " + lines[0].color)
			.attr("d", d3.svg.area().interpolate('basis').x(lineX).y0(zero).y1(lines[0].y));
		// hits
		enter.append("svg:path")
			.attr("class", "area")
			.attr("style", "stroke: " + lines[1].color + "; fill: " + lines[1].color)
			.attr("d", d3.svg.area().interpolate('basis').x(lineX).y0(zero).y1(lines[1].y));
	});
}

function concurrencyGraph(parentElem, dataUrl, label, width, height) {
	//Create SVG element
	var graph = createGraph(parentElem, label, width, height, 'concurrency-graph');

	var lineX = function(d) { return graph.scales.x(d.timestamp); };
	var lines = [
		{ label: 'min', color: colors(0), x: lineX, y: function(d) { return graph.scales.y(d.min); }},
		{ label: 'avg', color: colors(1), x: lineX, y: function(d) { return graph.scales.y(d.avg); }},
		{ label: 'max', color: colors(2), x: lineX, y: function(d) { return graph.scales.y(d.max); }}];

	labels(graph.svg, lines);
	graph.svg = graph.svg.append("g")
		.attr("transform", "translate(" + margin.left + "," + margin.top + ")");

	d3.json(dataUrl, function(error, data) {
		data.forEach(function(item) {
			item.timestamp = new Date(+ item.timestamp);
		});

		if (data.length != 0) {
			graph.scales.x.domain([data[0].timestamp, data[data.length - 1].timestamp]);
			graph.scales.y.domain([0, d3.max(data, function (d) { return d.max; })]);
		}

		graph.axes.addToGraph();

		var enter = graph.svg.selectAll(".concurrency")
			.data([data])
			.enter();

		lines.forEach(function(line) {
			enter.append("svg:path")
				.attr("class", "concurrency-line")
				.attr("style", "stroke: " + line.color)
				.attr("d", d3.svg.line().interpolate('basis-open').x(line.x).y(line.y));
		});
	});
}

function problemsTable(parentElem, dataUrl) {
	var prTable = d3.select(parentElem)
		.append("table");
	prTable.attr("class", "issue-table");
	var header = prTable.append("thead").append("tr");
	header.append("th").text("Count");
	header.append("th").text("First");
	header.append("th").text("Message");
	var tableBody = prTable.append("tbody");

	d3.json(dataUrl, function(error, data) {
		data.forEach(function(item) {
			item.timestamp = new Date(+ item.timestamp);
			item.timestampFirst = new Date(+ item.timestampFirst);
			item.timestampLast = new Date(+ item.timestampLast);
		});

		var rowSelect = tableBody.selectAll("tr")
			.data(data)
			.enter()
			.append('tr');
		rowSelect.attr("class", function (d, i) { return "level-" + d.level;});

		rowSelect.append('td')
			.attr("class", "count")
			.text(function (d, i) {
				return d.count;
			});
		rowSelect.append('td')
			.attr("class", "first")
			.text(function (d, i) {
				return shortDate(d.timestampFirst);
			});
		rowSelect.append('td')
			.attr("class", "message")
			.text(function (d, i) {
				return d.message;
			});
	});

}

function responseTimesGraph(parentElem, dataUrl, label, width, height) {
	//Create SVG element
	var graph = createGraph(parentElem, label, width, height, 'statistics-graph');

	// override the y scale to turn it into log time
	graph.scales.y = d3.scale.log().range([height, 0]);
	graph.axes.y = d3.svg.axis().scale(graph.scales.y)
        .tickValues([1, 10, 100, 500, 1000, 5000, 10000, 30000, 60000, 300000, 600000, 1800000, 3600000])
        .tickFormat(function (d) {
            if (d < 1000) {
                return d + "ms";
            } else if (d < 60000) {
                return (d / 1000)  + "s";
            } else if (d < 3600000) {
                return (d / 60000) + "m";
            } else {
                return (d / 3600000) + "h";
            }
        })
        .orient("right")

	var safeY = function (val) {
		var res = graph.scales.y(Math.max(1, val));
		if (res < 30) {
			console.log('val = ' + val + ", log = " + res);
		}
		return res;
	};
	var lineX = function(d) { return graph.scales.x(d.timestamp); };
	var lines = [
		{ label: 'min', color: colors(0), x: lineX, y: function(d) { return safeY(d.min); }},
		{ label: 'avg', color: colors(1), x: lineX, y: function(d) { return safeY(d.avg); }},
		{ label: 'max', color: colors(2), x: lineX, y: function(d) { return safeY(d.max); }}];

	labels(graph.svg, lines);
	graph.svg = graph.svg.append("g")
		.attr("transform", "translate(" + margin.left + "," + margin.top + ")");

	d3.json(dataUrl, function(error, data) {
		data.forEach(function(item) {
			item.timestamp = new Date(+ item.timestamp);
		});

		if (data.length != 0) {
			graph.scales.x.domain([data[0].timestamp, data[data.length - 1].timestamp]);
			graph.scales.y.domain([1, 3600000 * (d3.max(data, function (d) { return d.max; }) / 3600000 + 1)]);
		}

		graph.axes.addToGraph();

		var enter = graph.svg.selectAll(".statistics")
			.data([data])
			.enter();

		lines.forEach(function(line) {
			enter.append("svg:path")
				.attr("class", "statistics-line")
				.attr("style", "stroke: " + line.color)
				.attr("d", d3.svg.line().interpolate('basis').x(line.x).y(line.y));
		});
	});
}

function requestsPerMinuteGraph(parentElem, dataUrl, label, width, height) {
	//Create SVG element
	var graph = createGraph(parentElem, label, width, height, 'rpm-graph');

	var lineX = function(d) { return graph.scales.x(d.timestamp); };
	var lines = [
		{ label: 'rpm', color: colors(0), x: lineX, y: function(d) { return graph.scales.y(d.requestsPerMinute); }}];

	labels(graph.svg, lines);
	graph.svg = graph.svg.append("g")
		.attr("transform", "translate(" + margin.left + "," + margin.top + ")");

	d3.json(dataUrl, function(error, data) {
		data.forEach(function(item) {
			item.timestamp = new Date(+ item.timestamp);
		});

		if (data.length != 0) {
			graph.scales.x.domain([data[0].timestamp, data[data.length - 1].timestamp]);
			graph.scales.y.domain([0, d3.max(data, function (d) { return d.requestsPerMinute; })]);
		}

		graph.axes.addToGraph();

		var enter = graph.svg.selectAll(".rpm")
			.data([data])
			.enter();

		lines.forEach(function(line) {
			enter.append("svg:path")
				.attr("class", "rpm-line")
				.attr("style", "stroke: " + line.color)
				.attr("d", d3.svg.line().interpolate('basis-open').x(line.x).y(line.y));
		});
	});
}

function addCacheRatioGraphs(elem, collection, operationsMap) {
	elem.each(function (d, i) {
		cacheRatioGraph(this, getDataUrl(collection, d, 100),
			'Cache Ratio - ' + operationsMap[d.operation].capitalize(), 1000, 400);
	});
}

function addConcurrencyGraphs(elem, collection, operationsMap) {
	elem.each(function (d, i) {
		concurrencyGraph(this, getDataUrl(collection, d),
			'Concurrency - ' + operationsMap[d.operation].capitalize(), 1000, 400);
	});
}

function addProblemsTable(elem, collection) {
	elem.each(function (d, i) {
		problemsTable(this, getDataUrl(collection, d));
	});
}

function addResponseTimeGraphs(elem, collection, operationsMap) {
	elem.each(function (d, i) {
		responseTimesGraph(this, getDataUrl(collection, d),
			'Response times - ' + operationsMap[d.operation].capitalize(), 1000, 400);
	});
}

function addRequestsPerMinuteGraphs(elem, collection, operationsMap) {
	elem.each(function (d, i) {
		requestsPerMinuteGraph(this, getDataUrl(collection, d),
			'Requests per minute - ' + operationsMap[d.operation].capitalize(), 1000, 400);
	});
}

function getDataUrl(collection, data, dataPoints) {
	var url = '/collections/' + collection + '/data/';
	if (data.operation === '_') {
		url = url + data.type;
	} else {
		url = url + data.operation + '/' + data.type;
	}
	var sep = '?'
	if (data.dateFrom != undefined) {
		url += sep + 'from=' + data.dateFrom;
		sep = '&';
	}
	if (data.dateTo != undefined) {
		url += sep + 'to=' + data.dateTo;
		sep = '&';
	}
	if (data.dateFrom != undefined && data.dateTo != undefined) {
		// scale the requests
		var rangeMinutes = (new Date(data.dateTo) - new Date(data.dateFrom)) / 60000;
		var intervalMinutes = 1 + Math.floor(rangeMinutes / (dataPoints | 500));
		if (isNaN(intervalMinutes)) {
			intervalMinutes = 5;
		}
		url += sep + 'interval=' + intervalMinutes;
	}
	return url;
}

function showAvailableData(collection) {
	var graph = d3.select("#available-data")
		.append("svg")
		.attr("class", "available-data-calendar")
		.attr("width", 150)
		.attr("height", 404)
        .append("g")
        .attr("transform", "translate(20, 20)");

    graph.append("text").attr("text-anchor", "middle").attr("y", -5).attr("x", 7).attr("class", "weekday").text("S");
    graph.append("text").attr("text-anchor", "middle").attr("y", -5).attr("x", 20).attr("class", "weekday").text("M");
    graph.append("text").attr("text-anchor", "middle").attr("y", -5).attr("x", 33).attr("class", "weekday").text("T");
    graph.append("text").attr("text-anchor", "middle").attr("y", -5).attr("x", 46).attr("class", "weekday").text("W");
    graph.append("text").attr("text-anchor", "middle").attr("y", -5).attr("x", 59).attr("class", "weekday").text("T");
    graph.append("text").attr("text-anchor", "middle").attr("y", -5).attr("x", 72).attr("class", "weekday").text("F");
    graph.append("text").attr("text-anchor", "middle").attr("y", -5).attr("x", 85).attr("class", "weekday").text("S");

    d3.json('/collections/' + collection + '/days', function(error, data) {
        var dates = new Set(data);
        var today = new Date();
        var calStart = new Date();
        calStart.setMonth(today.getMonth() + 1);
        calStart.setDate(0); // move to the last day of the current month
        calStart.setDate(calStart.getDate() - (calStart.getDay() % 6)); // the Sunday before

        var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        for (w = 0; w < 26; ++w) {
            var week = graph.append("g")
                .attr("transform", "translate(0," + 14 * w + ")");
            var weekStart = new Date(calStart);
            weekStart.setDate(weekStart.getDate() - 7 * w);
            var legend = undefined;
            for (d = 0; d < 7; ++d) {
                var day = new Date(weekStart);
                day.setDate(day.getDate() + d);
                if (day.getDate() == 15) {
                    legend = monthNames[day.getMonth()];
                }
                var dateString = day.toISOString().slice(0, 10);
                var color = day > today ? "#e5e5e5" : "#d0d0d0";
                if (dates.has(dateString)) {
                    color = "#005A78";
                }
                week.append("rect")
                    .attr("width", 12)
                    .attr("height", 12)
                    .attr("x", 13 * d)
                    .attr("fill", color)
                    .attr("data-date", dateString);
            }
            if (legend) {
                week.append("text").attr("x", 96).attr("y", -4).attr("class", "weekday").text(legend);
            }
        }
        var rects = AJS.$("#available-data rect");
        rects.tooltip({title: 'data-date', delayIn: 250, delayOut: 250, gravity: 's'});
        rects.click(function () {
            updateDateRange(this.getAttribute('data-date'));
        });
        if (data && data[0]) {
            updateDateRange(data[0]);
        }
    });

}

function GraphRequest(operations, dateFrom, dateTo, graphType, dataType) {
	this.dateFrom = (dateFrom == undefined || dateFrom === '') ? undefined : dateFrom;
	this.dateTo = (dateTo == undefined || dateTo === '') ? undefined : dateTo;
	this.operations = operations;
	this.graphType = graphType;
	this.type = dataType;

	var self = this;

	this.toData = function() {
		return operations.map(function (op) {
			return {
				operation: op,
				dateFrom: self.dateFrom,
				dateTo: self.dateTo,
				graphType: self.graphType,
				type: self.type
			};
		})
	}
}

